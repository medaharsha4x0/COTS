export type UserRole = 'customer' | 'staff' | 'delivery_agent' | 'admin';

export type OrderStatus =
  | 'Order Placed'
  | 'Order Confirmed'
  | 'Packed'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Delivery Failed'
  | 'Cancelled';

export type PaymentStatus = 'Paid' | 'Pending' | 'Refunded';

export type PaymentMethod = 'Card' | 'Bank Transfer' | 'UPI' | 'Cash on Delivery';

export const CORE_MILESTONES: OrderStatus[] = [
  'Order Placed',
  'Order Confirmed',
  'Packed',
  'Shipped',
  'Out for Delivery',
  'Delivered',
];

export const VALIDATION_LIMITS = {
  idMax: 128,
  idPattern: /^[a-zA-Z0-9_-]+$/,
  nameMax: 120,
  emailMax: 180,
  phoneMax: 32,
  addressMax: 300,
  cityMax: 120,
  descMax: 320,
  productDescMax: 600,
  cancellationReasonMax: 240,
} as const;

export const CUSTOMER_CANCELLATION_REASONS = [
  'Changed my mind',
  'Ordered wrong item or variant',
  'Expected delivery is too late',
  'Need to update delivery address',
  'Found a better alternative',
  'Other',
] as const;

export const OPS_CANCELLATION_REASONS = [
  'Customer requested cancellation',
  'Item out of stock / damaged in warehouse',
  'Unserviceable delivery address',
  'Payment verification issue',
  'Duplicate order detected',
  'Other',
] as const;

export function isOrderCancellable(status: OrderStatus, role: UserRole): boolean {
  if (status === 'Delivered' || status === 'Cancelled') return false;
  if (role === 'customer') {
    return status === 'Order Placed' || status === 'Order Confirmed';
  }
  if (role === 'staff') {
    return status === 'Order Placed' || status === 'Order Confirmed' || status === 'Packed';
  }
  if (role === 'admin') {
    return true;
  }
  return false;
}

export interface CustomerProfile {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  defaultAddress?: string;
  cityRegion?: string;
  totalOrders: number;
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  productId: string;
  sku: string;
  name: string;
  category: string;
  description?: string;
  price: number;
  stock: number;
  imageUrl: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  orderItemId: string;
  orderId: string;
  customerUid: string;
  productId: string;
  productName: string;
  productImage?: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface ShipmentTrackingEntry {
  trackingId: string;
  orderId: string;
  status: OrderStatus;
  location: string;
  description: string;
  updatedByUid: string;
  updatedByRole: UserRole;
  timestamp: string;
}

export interface Order {
  orderId: string;
  customerUid: string;
  customerName: string;
  customerEmail: string;
  phone?: string;
  deliveryAddress: string;
  cityRegion: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  totalAmount: number;
  itemCount: number;
  expectedDelivery: string;
  assignedAgentUid?: string;
  assignedAgentName?: string;
  cancellationReason?: string;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
  items?: OrderItem[];
}

export interface OrderTrackingRecord {
  orderId: string;
  customerUid: string;
  currentStatus: OrderStatus;
  paymentStatus: PaymentStatus;
  cityRegion: string;
  expectedDelivery: string;
  totalAmount: number;
  itemSummary: string;
  itemCount: number;
  cancellationReason?: string;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
  // Enriched fields when viewer has permission or in demo lookup
  deliveryAddress?: string;
  customerName?: string;
  items?: OrderItem[];
  history: ShipmentTrackingEntry[];
}

export interface StaffMember {
  uid: string;
  name: string;
  email: string;
  department: string;
  shift: string;
  isActive: boolean;
  createdAt: string;
}

export interface DeliveryAgent {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  vehicleType: string;
  zone: string;
  isActive: boolean;
  createdAt: string;
}

export interface PaymentRecord {
  paymentId: string;
  orderId: string;
  customerUid: string;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  transactionRef: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type AppView =
  | 'landing'
  | 'track'
  | 'products'
  | 'about'
  | 'customer-dashboard'
  | 'staff-dashboard'
  | 'agent-dashboard'
  | 'admin-dashboard';
