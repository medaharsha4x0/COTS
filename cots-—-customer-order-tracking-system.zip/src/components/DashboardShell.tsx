import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowLeft,
  ChevronRight,
  LogOut,
  Menu,
  PackageCheck,
  ShieldAlert,
  ShoppingBag,
  X,
} from 'lucide-react';
import { useCots } from '../context/CotsContext';
import { UserRole } from '../types/cots';

export interface SidebarNavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
}

interface DashboardShellProps {
  requiredRole: UserRole;
  workspaceTitle: string;
  navItems: SidebarNavItem[];
  activeTab: string;
  onSelectTab: (id: string) => void;
  children: React.ReactNode;
}

export const DashboardShell: React.FC<DashboardShellProps> = ({
  requiredRole,
  workspaceTitle,
  navItems,
  activeTab,
  onSelectTab,
  children,
}) => {
  const {
    authMode,
    userRole,
    activeUserName,
    activeUserEmail,
    setView,
    setAuthModalOpen,
    enterDemoMode,
    logout,
    cart,
    setCartOpen,
  } = useCots();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAuthorized =
    authMode !== 'guest' && (userRole === requiredRole || userRole === 'admin');

  if (!isAuthorized) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-[#F8FAFC] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-2xl p-8 shadow-sm text-center">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">Access Restricted</h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            {authMode === 'guest'
              ? `Please sign in or enter the Demonstration Sandbox to access the ${workspaceTitle}.`
              : `Your current role (${userRole.replace('_', ' ')}) does not have permission to open the ${workspaceTitle}.`}
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Sign In / Switch Demo Role
            </button>
            <button
              type="button"
              onClick={() => setView('landing')}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Return Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const cartCount = cart.reduce((s, c) => s + c.quantity, 0);

  const renderSidebarBody = (isMobile = false) => (
    <div className="flex flex-col h-full justify-between p-4">
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <button
            type="button"
            onClick={() => setView('landing')}
            className="inline-flex items-center gap-2 text-base font-extrabold text-slate-900 cursor-pointer"
          >
            <span className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center">
              <PackageCheck className="w-4 h-4" />
            </span>
            <span className="font-display">COTS</span>
          </button>
          {isMobile && (
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectTab(item.id);
                if (isMobile) setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === item.id
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {item.icon}
              <span className="truncate">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="pt-4 border-t border-slate-200 space-y-1">
          <div className="px-3 pb-1 text-[11px] font-semibold text-slate-400">
            Quick Navigation
          </div>
          <button
            type="button"
            onClick={() => setView('track')}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-lg cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
            <span>Track Order by ID</span>
          </button>
          <button
            type="button"
            onClick={() => setView('products')}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-lg cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
            <span>Storefront Catalog</span>
          </button>
          <button
            type="button"
            onClick={() => setView('landing')}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-lg cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Public Homepage</span>
          </button>
        </div>

        {/* In Demo mode or Admin oversight, allow switching portals cleanly */}
        {(authMode === 'demo' || userRole === 'admin') && (
          <div className="pt-4 border-t border-slate-200 space-y-1">
            <div className="px-3 pb-1 text-[11px] font-semibold text-slate-400">
              {authMode === 'demo' ? 'Switch Demo Persona' : 'Admin Role Views'}
            </div>
            {(
              [
                ['customer', 'Customer View', 'customer-dashboard'],
                ['staff', 'Staff View', 'staff-dashboard'],
                ['delivery_agent', 'Agent View', 'agent-dashboard'],
                ['admin', 'Admin View', 'admin-dashboard'],
              ] as const
            ).map(([r, label, targetView]) => (
              <button
                key={r}
                type="button"
                onClick={() => {
                  if (authMode === 'demo') {
                    enterDemoMode(r);
                  } else {
                    setView(targetView);
                  }
                  if (isMobile) setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-1.5 text-xs rounded-md transition-colors cursor-pointer ${
                  requiredRole === r
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="pt-4 border-t border-slate-200 space-y-3">
        <div className="px-2">
          <div className="text-xs font-bold text-slate-900 truncate">{activeUserName}</div>
          <div className="text-[11px] text-slate-500 truncate">{activeUserEmail}</div>
          <div className="text-[11px] font-medium text-blue-600 mt-0.5">
            {authMode === 'live' ? 'Live Cloud Session' : 'Demonstration Sandbox'}
          </div>
        </div>
        <button
          type="button"
          onClick={logout}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex">
      {/* Desktop Animated Collapsible Sidebar */}
      <AnimatePresence initial={false}>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 256, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="hidden lg:block shrink-0 bg-white border-r border-slate-200 overflow-hidden"
          >
            <div className="w-64 h-screen sticky top-0 overflow-y-auto">
              {renderSidebarBody(false)}
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Mobile Drawer Sidebar */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/40 lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          >
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="w-64 h-full bg-white border-r border-slate-200 overflow-y-auto"
            >
              {renderSidebarBody(true)}
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Viewport */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => {
                if (window.innerWidth < 1024) setMobileMenuOpen(true);
                else setSidebarOpen((p) => !p);
              }}
              aria-label="Toggle workspace sidebar"
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm truncate">
              <span className="text-slate-400 hidden sm:inline">COTS</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <span className="font-bold text-slate-900 truncate">{workspaceTitle}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="hidden sm:inline text-xs font-medium text-slate-500">
              {authMode === 'live' ? 'Live Firestore' : 'Demo Mode'}
            </span>
            {requiredRole === 'customer' && (
              <button
                type="button"
                onClick={() => setCartOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Cart ({cartCount})</span>
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
