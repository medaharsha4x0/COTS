import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowRight,
  Box,
  CheckCircle2,
  Package,
  Search,
  ShieldCheck,
  ShoppingBag,
  Truck,
} from 'lucide-react';
import { useCots } from '../context/CotsContext';
import { HERO_IMAGE_URL } from '../data/demoData';
import { formatINR } from '../lib/currency';

export const LandingPage: React.FC = () => {
  const {
    navigateToTrack,
    setView,
    products,
    addToCart,
    setAuthModalOpen,
    authMode,
    userRole,
  } = useCots();

  const [orderInput, setOrderInput] = useState('');
  const [heroImgError, setHeroImgError] = useState(false);

  const handleHeroTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderInput.trim()) {
      navigateToTrack('COTS-2026-1042');
      return;
    }
    navigateToTrack(orderInput.trim());
  };

  const featuredProducts = products.slice(0, 4);

  return (
    <div className="bg-[#F8FAFC] text-slate-900">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-16 lg:pt-16 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <p className="text-xs font-semibold text-blue-600 tracking-wide mb-3">
              Customer Order Tracking System
            </p>
            <h1
              className="font-display font-extrabold text-slate-900 tracking-tight leading-[1.1] text-balance mb-5"
              style={{ fontSize: 'clamp(2.25rem, 4vw, 3.35rem)' }}
            >
              Track Your Orders. Stay Informed.
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl mb-8">
              Experience smarter order tracking with real-time delivery updates and complete shipment visibility.
            </p>

            {/* Prominent Order ID Tracker Form */}
            <form
              onSubmit={handleHeroTrack}
              className="bg-white border border-slate-200 rounded-xl p-2 shadow-sm flex flex-col sm:flex-row gap-2 max-w-xl"
            >
              <div className="relative flex-1 flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                <input
                  type="text"
                  value={orderInput}
                  onChange={(e) => setOrderInput(e.target.value)}
                  placeholder="Enter Order ID (e.g. COTS-2026-1042)"
                  aria-label="Order ID"
                  className="w-full pl-10 pr-3 py-2.5 text-sm font-mono text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:outline-none rounded-lg"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Track Order
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Quick Sample Demo IDs + Secondary Explore Products */}
            <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-500">
              <span>Demo Order IDs:</span>
              {['COTS-2026-1042', 'COTS-2026-1038', 'COTS-2026-1045'].map((sampleId) => (
                <button
                  key={sampleId}
                  type="button"
                  onClick={() => navigateToTrack(sampleId)}
                  className="font-mono text-blue-600 hover:text-blue-700 hover:underline cursor-pointer"
                >
                  {sampleId}
                </button>
              ))}
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setView('products')}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-800 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4 text-blue-600" />
                Explore Products
              </button>
              {authMode === 'guest' ? (
                <button
                  type="button"
                  onClick={() => setAuthModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  Open Role Sandbox or Sign In
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() =>
                    setView(
                      userRole === 'admin'
                        ? 'admin-dashboard'
                        : userRole === 'staff'
                          ? 'staff-dashboard'
                          : userRole === 'delivery_agent'
                            ? 'agent-dashboard'
                            : 'customer-dashboard'
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer"
                >
                  Go to Your Dashboard
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>

          {/* Hero Visual */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.05 }}
            className="lg:col-span-6 flex"
          >
            <div className="w-full rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-sm min-h-[300px] lg:min-h-[420px]">
              {!heroImgError ? (
                <img
                  src={HERO_IMAGE_URL}
                  alt="Modern fulfillment hub preparing tracked customer shipments"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-blue-50 via-slate-50 to-indigo-50 flex flex-col items-center justify-center p-10 text-center">
                  <Truck className="w-12 h-12 text-blue-600 mb-3" />
                  <p className="text-sm font-semibold text-slate-900">
                    COTS Precision Fulfillment Network
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Six verified milestone checkpoints from checkout to doorstep
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Full-Width Key Operational Metrics Strip */}
        <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4 bg-white border border-slate-200 rounded-xl p-6">
          <div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums">6 Stages</div>
            <div className="text-xs text-slate-500 mt-1">End-to-end milestone visibility</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums">4 Portals</div>
            <div className="text-xs text-slate-500 mt-1">Customer, Staff, Courier & Admin</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums">Atomic Sync</div>
            <div className="text-xs text-slate-500 mt-1">Inventory updates on every order</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums">Timestamped</div>
            <div className="text-xs text-slate-500 mt-1">Verified audit log per status change</div>
          </div>
        </div>
      </section>

      {/* 01-04 Core Platform Architecture */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 border-t border-slate-200">
        <div className="max-w-2xl mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Built for transparent fulfillment from checkout to doorstep
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Every role works from one synchronized ledger so customers see accurate milestones without guesswork.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold text-blue-600">01. Instant Order Lookup</span>
              <h3 className="text-xl font-bold text-slate-900 mt-2">
                Single Order ID tracking across all six milestones
              </h3>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed max-w-xl">
                Customers check progress from Order Placed through Confirmed, Packed, Shipped, Out for Delivery, and Delivered using their unique COTS Order ID—complete with hub locations and verified timestamps.
              </p>
            </div>
            <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-3 sm:grid-cols-6 gap-2 text-xs text-slate-600">
              <div className="flex items-center gap-1.5 font-medium text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Placed</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Confirmed</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Packed</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Shipped</span>
              </div>
              <div className="flex items-center gap-1.5 font-semibold text-blue-600">
                <Truck className="w-3.5 h-3.5 shrink-0" />
                <span>Out</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-400">
                <Package className="w-3.5 h-3.5 shrink-0" />
                <span>Delivered</span>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold text-indigo-600">02. Warehouse Packing</span>
              <h3 className="text-lg font-bold text-slate-900 mt-2">
                Staff fulfillment & stock control
              </h3>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                Store staff confirm incoming orders, pack parcels, assign delivery agents, and manage SKU stock levels in real time.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center gap-2">
              <Box className="w-4 h-4 text-indigo-600" />
              <span>Automatic inventory deduction on checkout</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
            <span className="text-xs font-semibold text-blue-600">03. Last-Mile Dispatch</span>
            <h3 className="text-lg font-bold text-slate-900 mt-2">
              Dedicated delivery agent portal
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Couriers view assigned drops, contact details, and log Out for Delivery, Delivered, or Delivery Failed timestamps.
            </p>
          </div>

          <div className="md:col-span-2 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <span className="text-xs font-semibold text-indigo-600">04. Executive Oversight</span>
              <h3 className="text-lg font-bold text-slate-900 mt-2">
                Admin analytics, role security & CSV reporting
              </h3>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed max-w-xl">
                Administrators monitor revenue, shipment bottlenecks, customer directories, staff rosters, and export instant operational reports.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              Explore Dashboards
            </button>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 border-t border-slate-200">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Featured Hardware & Gear
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Place an order to receive a live tracking ID and follow every fulfillment step.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setView('products')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            View All Products ({products.length})
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <div
              key={product.productId}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-slate-300 hover:shadow-md transition-all flex flex-col"
            >
              <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-[1.03] transition-transform duration-300"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-2">
                    <span>{product.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{product.stock} in stock</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mt-1 leading-snug">
                    {product.name}
                  </h3>
                </div>
                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-base font-bold text-slate-900 tabular-nums">
                    {formatINR(product.price)}
                  </span>
                  <button
                    type="button"
                    disabled={product.stock <= 0}
                    onClick={() => addToCart(product, 1)}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* About Us Section */}
      <section id="about-cots" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 border-t border-slate-200">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold text-blue-600 mb-2">About COTS</p>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Honest shipment visibility without simulated telemetry
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-3 leading-relaxed">
              COTS connects your storefront checkout directly to warehouse packing desks and courier handoffs. Rather than inventing synthetic live GPS pins, every milestone reflects verified warehouse scans, courier dispatch logs, and authentic delivery timestamps.
            </p>
          </div>
          <div className="lg:col-span-5 flex flex-col sm:flex-row lg:flex-col gap-3 lg:items-end">
            <button
              type="button"
              onClick={() => navigateToTrack('COTS-2026-1042')}
              className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              Inspect Live Tracking Timeline
            </button>
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              Try Role-Based Dashboards
            </button>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2 font-semibold text-slate-800">
            <span>COTS — Customer Order Tracking System</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => setView('track')} className="hover:text-slate-900 cursor-pointer">
              Track Order
            </button>
            <button onClick={() => setView('products')} className="hover:text-slate-900 cursor-pointer">
              Catalog
            </button>
            <button onClick={() => setAuthModalOpen(true)} className="hover:text-slate-900 cursor-pointer">
              Portal Access
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
