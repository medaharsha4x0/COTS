import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  Box,
  Calendar,
  Check,
  ClipboardCheck,
  Clock,
  CreditCard,
  Info,
  MapPin,
  Package,
  Search,
  Truck,
  XCircle,
} from 'lucide-react';
import { useCots } from '../context/CotsContext';
import { formatINR } from '../lib/currency';
import { CORE_MILESTONES, isOrderCancellable, OrderStatus, OrderTrackingRecord } from '../types/cots';
import { CancelOrderModal, CancelOrderTarget } from './ui/CancelOrderModal';
import { OrderStatusLabel, PaymentStatusLabel } from './ui/StatusBadge';
import { TrackingSkeleton } from './ui/Skeleton';

export const OrderTrackingView: React.FC = () => {
  const {
    activeTrackingId,
    setActiveTrackingId,
    trackOrder,
    authMode,
    activeUid,
    userRole,
    showToast,
  } = useCots();

  const [queryInput, setQueryInput] = useState(activeTrackingId || 'COTS-2026-1042');
  const [loading, setLoading] = useState(false);
  const [record, setRecord] = useState<OrderTrackingRecord | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<CancelOrderTarget | null>(null);

  const performLookup = async (idToFetch: string) => {
    const clean = idToFetch.trim().toUpperCase();
    if (!clean) {
      showToast('Please enter an Order ID to track.', 'error');
      return;
    }
    setLoading(true);
    setNotFound(false);
    try {
      const result = await trackOrder(clean);
      if (result) {
        setRecord(result);
        setNotFound(false);
      } else {
        setRecord(null);
        setNotFound(true);
      }
    } catch {
      setRecord(null);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeTrackingId) {
      setQueryInput(activeTrackingId);
      void performLookup(activeTrackingId);
    }
  }, [activeTrackingId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveTrackingId(queryInput.trim().toUpperCase());
    void performLookup(queryInput);
  };

  const getMilestoneState = (milestone: OrderStatus, current: OrderStatus) => {
    if (current === 'Cancelled') {
      if (milestone === 'Order Placed') return 'completed';
      return 'pending';
    }
    if (current === 'Delivery Failed') {
      const idx = CORE_MILESTONES.indexOf(milestone);
      if (idx <= 3) return 'completed';
      if (idx === 4) return 'failed';
      return 'pending';
    }
    const currentIndex = CORE_MILESTONES.indexOf(current);
    const milestoneIndex = CORE_MILESTONES.indexOf(milestone);
    if (current === 'Delivered') return 'completed';
    if (milestoneIndex < currentIndex) return 'completed';
    if (milestoneIndex === currentIndex) return 'current';
    return 'pending';
  };

  const progressPercentage = (() => {
    if (!record) return 0;
    if (record.currentStatus === 'Cancelled') return 10;
    if (record.currentStatus === 'Delivery Failed') return 75;
    const idx = CORE_MILESTONES.indexOf(record.currentStatus);
    if (idx < 0) return 0;
    return Math.round((idx / (CORE_MILESTONES.length - 1)) * 100);
  })();

  const milestoneIcon = (status: OrderStatus) => {
    switch (status) {
      case 'Order Placed':
        return <Clock className="w-4 h-4" />;
      case 'Order Confirmed':
        return <ClipboardCheck className="w-4 h-4" />;
      case 'Packed':
        return <Box className="w-4 h-4" />;
      case 'Shipped':
        return <Package className="w-4 h-4" />;
      case 'Out for Delivery':
        return <Truck className="w-4 h-4" />;
      case 'Delivered':
        return <Check className="w-4 h-4" />;
      case 'Delivery Failed':
        return <AlertTriangle className="w-4 h-4" />;
      case 'Cancelled':
        return <XCircle className="w-4 h-4" />;
    }
  };

  const findHistoryForMilestone = (milestone: OrderStatus) =>
    record?.history.find((h) => h.status === milestone);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-[#F8FAFC] py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Search Header */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Track Your Shipment
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Enter your unique COTS Order ID to view milestone progress, payment status, and verified dispatch timestamps.
          </p>

          <form onSubmit={handleSubmit} className="mt-5 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 flex items-center">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
              <input
                type="text"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="Enter Order ID (e.g. COTS-2026-1042)"
                aria-label="Order ID search"
                className="w-full pl-10 pr-4 py-2.5 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {loading ? 'Searching...' : 'Track Order'}
            </button>
          </form>

          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-500">
            <span>Sample Demo Orders:</span>
            {['COTS-2026-1042', 'COTS-2026-1038', 'COTS-2026-1045', 'COTS-2026-1049', 'COTS-2026-1031'].map(
              (id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    setQueryInput(id);
                    setActiveTrackingId(id);
                  }}
                  className={`font-mono cursor-pointer hover:underline ${
                    activeTrackingId === id ? 'text-blue-700 font-semibold' : 'text-blue-600'
                  }`}
                >
                  {id}
                </button>
              )
            )}
          </div>
        </div>

        {/* Loading State */}
        {loading && <TrackingSkeleton />}

        {/* Friendly Not Found Error */}
        {!loading && notFound && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-slate-200 rounded-xl p-10 text-center shadow-sm"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3">
              <Search className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold text-slate-900">Order ID Not Found</h2>
            <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
              We could not locate an order matching <span className="font-mono font-semibold">{queryInput}</span>. Please double-check the code on your receipt or select one of the sample Order IDs above.
            </p>
          </motion.div>
        )}

        {/* Populated Order Tracking Results */}
        {!loading && record && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            {/* Demo vs Live Data Transparency Banner */}
            <div className="bg-white border border-slate-200 rounded-xl px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  {record.isDemo
                    ? 'Demonstration Order Record: Hub checkpoints and courier route notes represent sample demonstration data rather than live GPS telemetry.'
                    : 'Connected Production Order: Milestone timestamps and hub locations reflect verified Firestore updates.'}
                </span>
              </div>
              <span className="font-mono font-medium text-slate-500">
                {record.isDemo ? 'DEMO DATASET' : 'LIVE RECORD'}
              </span>
            </div>

            {/* Order Summary Card */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="text-xs text-slate-500">Order ID</div>
                  <div className="text-2xl font-bold font-mono text-slate-900 mt-0.5 tabular-nums">
                    {record.orderId}
                  </div>
                </div>
                <div className="flex flex-col sm:items-end gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <OrderStatusLabel status={record.currentStatus} />
                    {authMode !== 'guest' &&
                      (record.customerUid === activeUid || userRole === 'staff' || userRole === 'admin') &&
                      isOrderCancellable(record.currentStatus, userRole) && (
                        <button
                          type="button"
                          onClick={() =>
                            setCancelTarget({
                              orderId: record.orderId,
                              status: record.currentStatus,
                              paymentStatus: record.paymentStatus,
                              totalAmount: record.totalAmount,
                              itemCount: record.itemCount,
                            })
                          }
                          className="inline-flex items-center gap-1 px-3 py-1 border border-red-200 bg-red-50/70 hover:bg-red-100 text-red-700 text-xs font-semibold rounded-md transition-colors cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Cancel Order
                        </button>
                      )}
                  </div>
                  <div className="text-xs text-slate-500 tabular-nums">
                    Last updated {new Date(record.updatedAt).toLocaleString()}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Order Date</span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900 tabular-nums">
                    {new Date(record.createdAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <Truck className="w-3.5 h-3.5" />
                    <span>Expected Delivery</span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900 tabular-nums">
                    {record.expectedDelivery}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Payment Status</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <PaymentStatusLabel status={record.paymentStatus} />
                    <span className="text-xs text-slate-500 tabular-nums">
                      · {formatINR(record.totalAmount)}
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Delivery Destination</span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900">
                    {record.deliveryAddress ? record.deliveryAddress : `${record.cityRegion} (Address protected)`}
                  </div>
                </div>
              </div>

              {/* Products Summary */}
              <div className="mt-6 pt-6 border-t border-slate-100">
                <div className="text-xs font-semibold text-slate-500 mb-3">
                  Items in Shipment ({record.itemCount})
                </div>
                {record.items && record.items.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {record.items.map((item) => (
                      <div
                        key={item.orderItemId}
                        className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 border border-slate-200/80"
                      >
                        {item.productImage ? (
                          <img
                            src={item.productImage}
                            alt={item.productName}
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 rounded-md object-cover border border-slate-200 shrink-0"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-md bg-slate-200 flex items-center justify-center shrink-0">
                            <Package className="w-5 h-5 text-slate-500" />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-semibold text-slate-900 truncate">
                            {item.productName}
                          </div>
                          <div className="text-xs text-slate-500 tabular-nums">
                            Qty {item.quantity} · {formatINR(item.unitPrice)} each
                          </div>
                        </div>
                        <div className="text-sm font-bold text-slate-900 tabular-nums">
                          {formatINR(item.subtotal)}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm font-medium text-slate-800">{record.itemSummary}</p>
                )}
              </div>
            </div>

            {/* 6-Milestone Animated Progress Timeline */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-8">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Shipment Milestone Timeline</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Green checkmarks indicate completed stages; blue indicates the active stage.
                  </p>
                </div>
                <span className="text-xs font-mono font-semibold text-blue-600 tabular-nums">
                  {progressPercentage}% Complete
                </span>
              </div>

              {/* Cancelled / Failed Notice */}
              {record.currentStatus === 'Cancelled' && (
                <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-red-900">Order Cancelled</p>
                    <p className="text-xs text-red-700 mt-0.5">
                      {record.cancellationReason
                        ? `Reason: ${record.cancellationReason}. `
                        : ''}
                      {record.paymentStatus === 'Refunded'
                        ? 'Prepaid payment has been marked as Refunded.'
                        : 'Review the event history below for full cancellation details.'}
                    </p>
                  </div>
                </div>
              )}

              {record.currentStatus === 'Delivery Failed' && (
                <div className="mb-6 p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-amber-900">Delivery Attempt Unsuccessful</p>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Our courier attempted delivery. See the latest timestamped note below for redelivery steps.
                    </p>
                  </div>
                </div>
              )}

              {/* Desktop Horizontal Animated Stepper */}
              <div className="hidden md:block relative pb-4">
                <div className="absolute top-5 left-8 right-8 h-1 bg-slate-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPercentage}%` }}
                    transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
                    className={`h-full rounded-full ${
                      record.currentStatus === 'Cancelled'
                        ? 'bg-red-500'
                        : record.currentStatus === 'Delivered'
                          ? 'bg-emerald-500'
                          : 'bg-blue-600'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-6 gap-3 relative">
                  {CORE_MILESTONES.map((milestone, index) => {
                    const state = getMilestoneState(milestone, record.currentStatus);
                    const matched = findHistoryForMilestone(milestone);

                    return (
                      <motion.div
                        key={milestone}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.22, delay: index * 0.05 }}
                        className="flex flex-col items-center text-center"
                      >
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all z-10 ${
                            state === 'completed'
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : state === 'current'
                                ? 'bg-blue-600 border-blue-600 text-white ring-4 ring-blue-100 animate-pulse'
                                : state === 'failed'
                                  ? 'bg-amber-500 border-amber-500 text-white ring-4 ring-amber-100'
                                  : 'bg-white border-slate-300 text-slate-400'
                          }`}
                        >
                          {state === 'completed' ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            milestoneIcon(milestone)
                          )}
                        </div>
                        <div
                          className={`mt-3 text-xs font-semibold ${
                            state === 'pending' ? 'text-slate-400' : 'text-slate-900'
                          }`}
                        >
                          {milestone}
                        </div>
                        <div className="mt-1 text-[11px] text-slate-500 tabular-nums">
                          {matched
                            ? new Date(matched.timestamp).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                              })
                            : state === 'pending'
                              ? 'Pending'
                              : ''}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Vertical Detailed Milestone Timeline (Always visible on mobile & detailed history) */}
              <div className="mt-4 md:mt-8 pt-6 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-900 mb-5">
                  Chronological Shipment Events ({record.history.length})
                </h3>
                <div className="space-y-0">
                  {[...record.history].reverse().map((entry, idx) => {
                    const isLatest = idx === 0;
                    const isDelivered = entry.status === 'Delivered';
                    const isCancelledOrFailed =
                      entry.status === 'Cancelled' || entry.status === 'Delivery Failed';

                    return (
                      <motion.div
                        key={entry.trackingId}
                        initial={{ opacity: 0, x: -6 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.2, delay: idx * 0.04 }}
                        className="relative pl-9 pb-6 last:pb-0"
                      >
                        {idx !== record.history.length - 1 && (
                          <div className="absolute left-[13px] top-7 bottom-0 w-px bg-slate-200" />
                        )}
                        <div
                          className={`absolute left-0 top-0.5 w-7 h-7 rounded-full flex items-center justify-center ${
                            isCancelledOrFailed
                              ? 'bg-red-100 text-red-700'
                              : isDelivered || !isLatest
                                ? 'bg-emerald-100 text-emerald-700'
                                : 'bg-blue-600 text-white ring-4 ring-blue-100'
                          }`}
                        >
                          {milestoneIcon(entry.status)}
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="text-sm font-bold text-slate-900">{entry.status}</div>
                          <div className="text-xs font-mono text-slate-500 tabular-nums">
                            {new Date(entry.timestamp).toLocaleString()}
                          </div>
                        </div>
                        <p className="text-sm text-slate-600 mt-1">{entry.description}</p>
                        <div className="text-xs text-slate-500 mt-1.5 flex flex-wrap items-center gap-2">
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {entry.location}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize">
                            Updated by {entry.updatedByRole.replace('_', ' ')}
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      <CancelOrderModal
        order={cancelTarget}
        role={userRole}
        locationLabel="Order Tracking Portal"
        onClose={() => setCancelTarget(null)}
        onCancelled={() => {
          if (record?.orderId) {
            void performLookup(record.orderId);
          }
        }}
      />
    </div>
  );
};
