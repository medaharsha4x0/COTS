import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  Clock,
  LayoutDashboard,
  Package,
  Search,
  ShoppingBag,
  User,
  XCircle,
} from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { formatINR } from '../../lib/currency';
import { isOrderCancellable } from '../../types/cots';
import { DashboardShell, SidebarNavItem } from '../DashboardShell';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { CancelOrderModal, CancelOrderTarget } from '../ui/CancelOrderModal';
import { OrderStatusLabel, PaymentStatusLabel } from '../ui/StatusBadge';
import { TableRowSkeleton } from '../ui/Skeleton';

export const CustomerDashboard: React.FC = () => {
  const {
    activeUid,
    activeUserName,
    activeUserEmail,
    customerProfile,
    orders,
    products,
    addToCart,
    navigateToTrack,
    updateProfile,
    dataLoading,
    showToast,
  } = useCots();

  const [tab, setTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [cancelTarget, setCancelTarget] = useState<CancelOrderTarget | null>(null);

  // Profile form state
  const [name, setName] = useState(customerProfile?.name || activeUserName);
  const [phone, setPhone] = useState(customerProfile?.phone || '');
  const [defaultAddress, setDefaultAddress] = useState(customerProfile?.defaultAddress || '');
  const [cityRegion, setCityRegion] = useState(customerProfile?.cityRegion || '');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (customerProfile) {
      setName(customerProfile.name || activeUserName);
      setPhone(customerProfile.phone || '');
      setDefaultAddress(customerProfile.defaultAddress || '');
      setCityRegion(customerProfile.cityRegion || '');
    }
  }, [customerProfile, activeUserName]);

  const myOrders = orders.filter((o) => o.customerUid === activeUid);

  const totalCount = myOrders.length;
  const activeCount = myOrders.filter(
    (o) => !['Delivered', 'Cancelled'].includes(o.status)
  ).length;
  const deliveredCount = myOrders.filter((o) => o.status === 'Delivered').length;
  const cancelledCount = myOrders.filter((o) => o.status === 'Cancelled').length;

  const filteredOrders = myOrders.filter((o) => {
    const q = searchQuery.trim().toLowerCase();
    return (
      !q ||
      o.orderId.toLowerCase().includes(q) ||
      o.status.toLowerCase().includes(q) ||
      o.cityRegion.toLowerCase().includes(q)
    );
  });

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      showToast('Name must be at least 2 characters.', 'error');
      return;
    }
    setSavingProfile(true);
    try {
      await updateProfile({
        name: name.trim(),
        phone: phone.trim(),
        defaultAddress: defaultAddress.trim(),
        cityRegion: cityRegion.trim(),
      });
    } finally {
      setSavingProfile(false);
    }
  };

  const navItems: SidebarNavItem[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'orders', label: 'Order History', icon: <Package className="w-4 h-4" /> },
    { id: 'browse', label: 'Browse Products', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'profile', label: 'Profile Settings', icon: <User className="w-4 h-4" /> },
  ];

  return (
    <DashboardShell
      requiredRole="customer"
      workspaceTitle="Customer Portal"
      navItems={navItems}
      activeTab={tab}
      onSelectTab={setTab}
    >
      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Welcome back, {activeUserName}
            </h1>
            <p className="text-sm text-slate-600 mt-0.5">
              Monitor active deliveries, browse hardware, or inspect any order timeline.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setTab('browse')}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            New Order
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-slate-200 rounded-xl p-5"
          >
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Total Orders</span>
              <Package className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-2xl font-bold text-slate-900 mt-2">
              <AnimatedCounter value={totalCount} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.04 }}
            className="bg-white border border-slate-200 rounded-xl p-5"
          >
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Active Orders</span>
              <Clock className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl font-bold text-blue-600 mt-2">
              <AnimatedCounter value={activeCount} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="bg-white border border-slate-200 rounded-xl p-5"
          >
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Delivered Orders</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-bold text-emerald-700 mt-2">
              <AnimatedCounter value={deliveredCount} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.12 }}
            className="bg-white border border-slate-200 rounded-xl p-5"
          >
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Cancelled Orders</span>
              <XCircle className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-2xl font-bold text-slate-900 mt-2">
              <AnimatedCounter value={cancelledCount} />
            </div>
          </motion.div>
        </div>

        {/* Overview & Order History */}
        {(tab === 'overview' || tab === 'orders') && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {tab === 'overview' ? 'Recent Orders' : 'Full Order History'}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Orders placed with your account are connected directly to tracking IDs.
                </p>
              </div>
              <div className="relative w-full sm:w-64 flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter by Order ID..."
                  className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>
            </div>

            {dataLoading ? (
              <TableRowSkeleton rows={4} />
            ) : filteredOrders.length === 0 ? (
              <div className="p-10 text-center">
                <Package className="w-9 h-9 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-900">No orders yet</p>
                <p className="text-xs text-slate-500 mt-1 mb-4">
                  Place your first order from the product catalog to start tracking it.
                </p>
                <button
                  type="button"
                  onClick={() => setTab('browse')}
                  className="px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Browse Products
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                      <th className="py-3 px-4">Order ID</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Destination</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Payment</th>
                      <th className="py-3 px-4 text-right">Total</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {(tab === 'overview' ? filteredOrders.slice(0, 5) : filteredOrders).map((order) => {
                      const canCancel = isOrderCancellable(order.status, 'customer');
                      return (
                        <tr key={order.orderId} className="hover:bg-slate-50/60">
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="font-mono font-semibold text-slate-900">
                              {order.orderId}
                            </div>
                            {order.status === 'Cancelled' && order.cancellationReason && (
                              <div className="text-[11px] text-red-600 max-w-[200px] truncate mt-0.5">
                                {order.cancellationReason}
                              </div>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-xs text-slate-600 tabular-nums whitespace-nowrap">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </td>
                          <td className="py-3.5 px-4 text-xs text-slate-600 max-w-[200px] truncate">
                            {order.cityRegion}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <OrderStatusLabel status={order.status} />
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <PaymentStatusLabel status={order.paymentStatus} />
                          </td>
                          <td className="py-3.5 px-4 text-right font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                            {formatINR(order.totalAmount)}
                          </td>
                          <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-2">
                            <button
                              type="button"
                              onClick={() => navigateToTrack(order.orderId)}
                              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-md transition-colors cursor-pointer"
                            >
                              Track Order
                            </button>
                            {canCancel && (
                              <button
                                type="button"
                                onClick={() =>
                                  setCancelTarget({
                                    orderId: order.orderId,
                                    status: order.status,
                                    paymentStatus: order.paymentStatus,
                                    totalAmount: order.totalAmount,
                                    itemCount: order.itemCount,
                                  })
                                }
                                className="px-2.5 py-1.5 border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium rounded-md transition-colors cursor-pointer"
                              >
                                Cancel Order
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Inline Product Browsing */}
        {tab === 'browse' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {products
              .filter((p) => p.isActive)
              .map((product) => (
                <div
                  key={product.productId}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col"
                >
                  <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-xs text-slate-500">
                        {product.category} · {product.stock} in stock
                      </div>
                      <h3 className="text-base font-bold text-slate-900 mt-1">{product.name}</h3>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-base font-bold text-slate-900 tabular-nums">
                        {formatINR(product.price)}
                      </span>
                      <button
                        type="button"
                        disabled={product.stock <= 0}
                        onClick={() => addToCart(product, 1)}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* Profile Settings */}
        {tab === 'profile' && (
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-2xl">
            <h2 className="text-base font-bold text-slate-900 mb-1">Profile Settings</h2>
            <p className="text-xs text-slate-500 mb-5">
              Saved details prefill your delivery address at checkout.
            </p>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    disabled
                    value={activeUserEmail}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-slate-50 text-slate-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (415) 555-0194"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">City / Region</label>
                  <input
                    type="text"
                    value={cityRegion}
                    onChange={(e) => setCityRegion(e.target.value)}
                    placeholder="San Francisco, CA"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Default Delivery Address
                </label>
                <textarea
                  rows={2}
                  value={defaultAddress}
                  onChange={(e) => setDefaultAddress(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 resize-none"
                />
              </div>
              <button
                type="submit"
                disabled={savingProfile}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
              >
                {savingProfile ? 'Saving...' : 'Save Profile'}
              </button>
            </form>
          </div>
        )}
      </div>

      <CancelOrderModal
        order={cancelTarget}
        role="customer"
        locationLabel="Customer Portal"
        onClose={() => setCancelTarget(null)}
      />
    </DashboardShell>
  );
};
