import React, { useState } from 'react';
import {
  Box,
  ClipboardList,
  Eye,
  Minus,
  Package,
  Plus,
  Search,
  Truck,
  X,
} from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { formatINR } from '../../lib/currency';
import { isOrderCancellable, Order } from '../../types/cots';
import { DashboardShell, SidebarNavItem } from '../DashboardShell';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { CancelOrderModal, CancelOrderTarget } from '../ui/CancelOrderModal';
import { OrderStatusLabel } from '../ui/StatusBadge';

export const StaffDashboard: React.FC = () => {
  const {
    orders,
    products,
    deliveryAgents,
    updateOrderStatus,
    updateProductStock,
    loadOrderItems,
    navigateToTrack,
    showToast,
  } = useCots();

  const [tab, setTab] = useState('orders');
  const [searchId, setSearchId] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [hubLocation, setHubLocation] = useState('Bay Area Fulfillment Hub');
  const [statusNote, setStatusNote] = useState('');
  const [selectedAgentUid, setSelectedAgentUid] = useState('');
  const [updating, setUpdating] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<CancelOrderTarget | null>(null);

  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o) => o.status === 'Order Placed').length;
  const packingOrders = orders.filter(
    (o) => o.status === 'Order Confirmed' || o.status === 'Packed'
  ).length;
  const readyToShip = orders.filter((o) => o.status === 'Packed').length;

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      !searchId.trim() || o.orderId.toLowerCase().includes(searchId.trim().toLowerCase());
    const matchesStatus = statusFilter === 'All' || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const openOrderModal = async (order: Order) => {
    setSelectedOrder(order);
    setSelectedAgentUid(order.assignedAgentUid || deliveryAgents[0]?.uid || '');
    setStatusNote('');
    await loadOrderItems(order.orderId);
  };

  const handleStaffStatusChange = async (newStatus: 'Order Confirmed' | 'Packed' | 'Shipped') => {
    if (!selectedOrder) return;
    setUpdating(true);
    try {
      const agent = deliveryAgents.find((a) => a.uid === selectedAgentUid);
      const defaultDesc: Record<typeof newStatus, string> = {
        'Order Confirmed': 'Inventory verified and order confirmed by fulfillment staff.',
        Packed: 'Items packed, sealed, and labeled for carrier pickup.',
        Shipped: agent
          ? `Parcel dispatched and assigned to courier ${agent.name}.`
          : 'Parcel dispatched from fulfillment center.',
      };

      await updateOrderStatus({
        orderId: selectedOrder.orderId,
        newStatus,
        location: hubLocation.trim() || 'Fulfillment Center',
        description: statusNote.trim() || defaultDesc[newStatus],
        assignedAgentUid: agent?.uid,
        assignedAgentName: agent?.name,
      });
      setSelectedOrder(null);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Update failed.', 'error');
    } finally {
      setUpdating(false);
    }
  };

  const navItems: SidebarNavItem[] = [
    { id: 'orders', label: 'Fulfillment Queue', icon: <ClipboardList className="w-4 h-4" /> },
    { id: 'inventory', label: 'Product Inventory', icon: <Box className="w-4 h-4" /> },
  ];

  return (
    <DashboardShell
      requiredRole="staff"
      workspaceTitle="Fulfillment Staff Portal"
      navItems={navItems}
      activeTab={tab}
      onSelectTab={setTab}
    >
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Warehouse & Fulfillment Operations
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Confirm incoming orders, advance packing stages, and keep SKU stock accurate.
          </p>
        </div>

        {/* KPI Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Total Orders</div>
            <div className="text-2xl font-bold text-slate-900 mt-2">
              <AnimatedCounter value={totalOrders} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Pending Confirmation</div>
            <div className="text-2xl font-bold text-amber-600 mt-2">
              <AnimatedCounter value={pendingOrders} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">In Packing Pipeline</div>
            <div className="text-2xl font-bold text-blue-600 mt-2">
              <AnimatedCounter value={packingOrders} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Ready-to-Ship</div>
            <div className="text-2xl font-bold text-indigo-600 mt-2">
              <AnimatedCounter value={readyToShip} />
            </div>
          </div>
        </div>

        {tab === 'orders' && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
                {['All', 'Order Placed', 'Order Confirmed', 'Packed', 'Shipped', 'Cancelled'].map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                      statusFilter === st
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              <div className="relative w-full lg:w-64 flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  value={searchId}
                  onChange={(e) => setSearchId(e.target.value)}
                  placeholder="Search Order ID..."
                  className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Items</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Manage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredOrders.map((order) => (
                    <tr key={order.orderId} className="hover:bg-slate-50/60">
                      <td className="py-3.5 px-4 font-mono font-semibold text-slate-900 whitespace-nowrap">
                        {order.orderId}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-900">{order.customerName}</div>
                        <div className="text-xs text-slate-500">{order.cityRegion}</div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 tabular-nums">
                        {order.itemCount} item{order.itemCount === 1 ? '' : 's'}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <OrderStatusLabel status={order.status} />
                      </td>
                      <td className="py-3.5 px-4 text-right font-semibold tabular-nums">
                        {formatINR(order.totalAmount)}
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-2">
                        <button
                          type="button"
                          onClick={() => openOrderModal(order)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-md cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Process
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'inventory' && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Product Stock Control</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Adjust warehouse counts when new shipments arrive.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4">SKU</th>
                    <th className="py-3 px-4">Product</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4 text-right">Price</th>
                    <th className="py-3 px-4 text-right">Stock Level</th>
                    <th className="py-3 px-4 text-right">Adjust</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {products.map((p) => (
                    <tr key={p.productId}>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-600">{p.sku}</td>
                      <td className="py-3.5 px-4 font-semibold text-slate-900">{p.name}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-500">{p.category}</td>
                      <td className="py-3.5 px-4 text-right tabular-nums">{formatINR(p.price)}</td>
                      <td className="py-3.5 px-4 text-right font-bold tabular-nums">
                        <span className={p.stock <= 5 ? 'text-amber-700' : 'text-slate-900'}>
                          {p.stock}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => updateProductStock(p.productId, p.stock - 1)}
                            className="p-1.5 border border-slate-200 rounded-md hover:bg-slate-100 cursor-pointer"
                            aria-label="Decrease stock"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => updateProductStock(p.productId, p.stock + 5)}
                            className="px-2.5 py-1 border border-slate-200 rounded-md text-xs font-semibold hover:bg-slate-100 cursor-pointer"
                          >
                            +5
                          </button>
                          <button
                            type="button"
                            onClick={() => updateProductStock(p.productId, p.stock + 1)}
                            className="p-1.5 border border-slate-200 rounded-md hover:bg-slate-100 cursor-pointer"
                            aria-label="Increase stock"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Process Order Modal */}
      {selectedOrder && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center p-4"
          onClick={() => setSelectedOrder(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white border border-slate-200 rounded-2xl shadow-xl max-w-lg w-full overflow-hidden"
          >
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-500">Fulfillment Action</div>
                <h3 className="text-lg font-bold font-mono text-slate-900">
                  {selectedOrder.orderId}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[78vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-500 block">Customer</span>
                  <span className="font-semibold text-slate-900">{selectedOrder.customerName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Current Status</span>
                  <OrderStatusLabel status={selectedOrder.status} />
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block">Delivery Address</span>
                  <span className="font-medium text-slate-900">{selectedOrder.deliveryAddress}</span>
                </div>
              </div>

              {selectedOrder.items && selectedOrder.items.length > 0 && (
                <div className="border-t border-slate-100 pt-4 space-y-2">
                  <div className="text-xs font-semibold text-slate-500">Order Items</div>
                  {selectedOrder.items.map((item) => (
                    <div key={item.orderItemId} className="flex justify-between text-xs">
                      <span className="text-slate-800">
                        {item.productName} × {item.quantity}
                      </span>
                      <span className="font-semibold tabular-nums">{formatINR(item.subtotal)}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="border-t border-slate-100 pt-4 space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Fulfillment Hub Location
                  </label>
                  <input
                    type="text"
                    value={hubLocation}
                    onChange={(e) => setHubLocation(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Assign Courier (when shipping)
                  </label>
                  <select
                    value={selectedAgentUid}
                    onChange={(e) => setSelectedAgentUid(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    {deliveryAgents.map((a) => (
                      <option key={a.uid} value={a.uid}>
                        {a.name} · {a.zone}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tracking Log Note (optional)
                  </label>
                  <input
                    type="text"
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    placeholder="e.g. Packed in Bay 04 with protective cushion"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                {(['Order Confirmed', 'Packed', 'Shipped'] as const).map((nextStatus) => (
                  <button
                    key={nextStatus}
                    type="button"
                    disabled={
                      updating ||
                      selectedOrder.status === 'Delivered' ||
                      selectedOrder.status === 'Cancelled'
                    }
                    onClick={() => handleStaffStatusChange(nextStatus)}
                    className="flex-1 min-w-[120px] inline-flex items-center justify-center gap-1.5 px-3 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    {nextStatus === 'Shipped' ? <Truck className="w-3.5 h-3.5" /> : <Package className="w-3.5 h-3.5" />}
                    Mark {nextStatus}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
                {isOrderCancellable(selectedOrder.status, 'staff') ? (
                  <button
                    type="button"
                    disabled={updating}
                    onClick={() => {
                      const target: CancelOrderTarget = {
                        orderId: selectedOrder.orderId,
                        status: selectedOrder.status,
                        paymentStatus: selectedOrder.paymentStatus,
                        totalAmount: selectedOrder.totalAmount,
                        itemCount: selectedOrder.itemCount,
                      };
                      setSelectedOrder(null);
                      setCancelTarget(target);
                    }}
                    className="text-xs font-semibold text-red-600 hover:text-red-700 hover:underline cursor-pointer"
                  >
                    Cancel Order
                  </button>
                ) : (
                  <span />
                )}
                <button
                  type="button"
                  onClick={() => {
                    const id = selectedOrder.orderId;
                    setSelectedOrder(null);
                    navigateToTrack(id);
                  }}
                  className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
                >
                  Open Public Tracking Page →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <CancelOrderModal
        order={cancelTarget}
        role="staff"
        locationLabel={hubLocation.trim() || 'Fulfillment Center'}
        onClose={() => setCancelTarget(null)}
      />
    </DashboardShell>
  );
};
