import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  History,
  MapPin,
  Phone,
  Search,
  Truck,
} from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { Order } from '../../types/cots';
import { DashboardShell, SidebarNavItem } from '../DashboardShell';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { OrderStatusLabel } from '../ui/StatusBadge';

export const DeliveryAgentDashboard: React.FC = () => {
  const { orders, updateOrderStatus, navigateToTrack, showToast } = useCots();

  const [tab, setTab] = useState('assigned');
  const [searchId, setSearchId] = useState('');
  const [routeNote, setRouteNote] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  const activeQueue = orders.filter((o) =>
    ['Shipped', 'Out for Delivery', 'Delivery Failed'].includes(o.status)
  );
  const completedHistory = orders.filter((o) => o.status === 'Delivered');

  const filterList = (list: Order[]) =>
    list.filter(
      (o) => !searchId.trim() || o.orderId.toLowerCase().includes(searchId.trim().toLowerCase())
    );

  const handleAgentUpdate = async (
    order: Order,
    newStatus: 'Out for Delivery' | 'Delivered' | 'Delivery Failed'
  ) => {
    setBusyId(order.orderId);
    try {
      const defaults: Record<typeof newStatus, string> = {
        'Out for Delivery': 'Courier departed regional hub for doorstep delivery.',
        Delivered: 'Package delivered safely to recipient.',
        'Delivery Failed': 'Delivery attempted; recipient unavailable. Rescheduling next attempt.',
      };
      await updateOrderStatus({
        orderId: order.orderId,
        newStatus,
        location: `${order.cityRegion} · Courier Dispatch`,
        description: routeNote[order.orderId]?.trim() || defaults[newStatus],
      });
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Status update failed.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const navItems: SidebarNavItem[] = [
    { id: 'assigned', label: 'Assigned Deliveries', icon: <Truck className="w-4 h-4" /> },
    { id: 'history', label: 'Delivery History', icon: <History className="w-4 h-4" /> },
  ];

  return (
    <DashboardShell
      requiredRole="delivery_agent"
      workspaceTitle="Delivery Agent Portal"
      navItems={navItems}
      activeTab={tab}
      onSelectTab={setTab}
    >
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Last-Mile Delivery Dispatch
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Review assigned parcels, verify customer drop-off details, and log delivery outcomes.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Active Route Queue</div>
            <div className="text-2xl font-bold text-blue-600 mt-2">
              <AnimatedCounter value={activeQueue.length} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Out for Delivery</div>
            <div className="text-2xl font-bold text-slate-900 mt-2">
              <AnimatedCounter
                value={orders.filter((o) => o.status === 'Out for Delivery').length}
              />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">Completed Deliveries</div>
            <div className="text-2xl font-bold text-emerald-700 mt-2">
              <AnimatedCounter value={completedHistory.length} />
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Search assigned Order ID..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>
        </div>

        {tab === 'assigned' && (
          <div className="space-y-4">
            {filterList(activeQueue).length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
                <Truck className="w-9 h-9 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-900">No active dispatches</p>
                <p className="text-xs text-slate-500 mt-1">
                  Orders marked Shipped by fulfillment staff will appear here automatically.
                </p>
              </div>
            ) : (
              filterList(activeQueue).map((order) => (
                <div
                  key={order.orderId}
                  className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-base font-bold text-slate-900">
                          {order.orderId}
                        </span>
                        <OrderStatusLabel status={order.status} />
                      </div>
                      <div className="text-sm font-semibold text-slate-800 mt-1">
                        {order.customerName}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateToTrack(order.orderId)}
                      className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
                    >
                      View Timeline →
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600 bg-slate-50 rounded-lg p-3.5">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <span>{order.deliveryAddress}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>{order.phone || 'Contact via COTS dispatch'}</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                    <input
                      type="text"
                      value={routeNote[order.orderId] || ''}
                      onChange={(e) =>
                        setRouteNote((prev) => ({ ...prev, [order.orderId]: e.target.value }))
                      }
                      placeholder="Optional delivery note (e.g. Left with reception)..."
                      className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-lg"
                    />
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={busyId === order.orderId}
                        onClick={() => handleAgentUpdate(order, 'Out for Delivery')}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        Out for Delivery
                      </button>
                      <button
                        type="button"
                        disabled={busyId === order.orderId}
                        onClick={() => handleAgentUpdate(order, 'Delivered')}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Delivered
                      </button>
                      <button
                        type="button"
                        disabled={busyId === order.orderId}
                        onClick={() => handleAgentUpdate(order, 'Delivery Failed')}
                        className="inline-flex items-center gap-1.5 px-3 py-2 border border-amber-300 text-amber-800 hover:bg-amber-50 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Delivery Failed
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {tab === 'history' && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">Recipient</th>
                    <th className="py-3 px-4">Destination</th>
                    <th className="py-3 px-4">Completed At</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filterList(completedHistory).map((order) => (
                    <tr key={order.orderId}>
                      <td className="py-3.5 px-4 font-mono font-semibold">{order.orderId}</td>
                      <td className="py-3.5 px-4">{order.customerName}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">{order.cityRegion}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-500 tabular-nums">
                        {new Date(order.updatedAt).toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4">
                        <OrderStatusLabel status={order.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </DashboardShell>
  );
};
