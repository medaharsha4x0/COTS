import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Box,
  Database,
  Download,
  Package,
  Plus,
  Truck,
  UserCheck,
  Users,
} from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { DEMO_PRODUCTS } from '../../data/demoData';
import { formatINR } from '../../lib/currency';
import { CORE_MILESTONES, isOrderCancellable, OrderStatus } from '../../types/cots';
import { DashboardShell, SidebarNavItem } from '../DashboardShell';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { CancelOrderModal, CancelOrderTarget } from '../ui/CancelOrderModal';
import { OrderStatusLabel, PaymentStatusLabel } from '../ui/StatusBadge';

export const AdminDashboard: React.FC = () => {
  const {
    authMode,
    orders,
    products,
    customers,
    staffList,
    deliveryAgents,
    payments,
    updateOrderStatus,
    saveProduct,
    saveStaff,
    saveAgent,
    seedCatalogToFirestore,
    navigateToTrack,
    showToast,
  } = useCots();

  const [tab, setTab] = useState('analytics');
  const [cancelTarget, setCancelTarget] = useState<CancelOrderTarget | null>(null);

  // Add Product Form State
  const [pName, setPName] = useState('');
  const [pSku, setPSku] = useState('');
  const [pCategory, setPCategory] = useState('Workspace');
  const [pPrice, setPPrice] = useState('4990');
  const [pStock, setPStock] = useState('25');

  // Add Staff Form State
  const [sUid, setSUid] = useState('');
  const [sName, setSName] = useState('');
  const [sEmail, setSEmail] = useState('');
  const [sDept, setSDept] = useState('Regional Fulfillment');

  // Add Delivery Agent Form State
  const [aUid, setAUid] = useState('');
  const [aName, setAName] = useState('');
  const [aEmail, setAEmail] = useState('');
  const [aZone, setAZone] = useState('Metro West');
  const [aVehicle, setAVehicle] = useState('Electric Cargo Van');

  const totalRevenue = useMemo(
    () =>
      orders
        .filter((o) => o.status !== 'Cancelled')
        .reduce((sum, o) => sum + o.totalAmount, 0),
    [orders]
  );
  const activeShipments = orders.filter(
    (o) => !['Delivered', 'Cancelled'].includes(o.status)
  ).length;
  const deliveredOrders = orders.filter((o) => o.status === 'Delivered').length;
  const totalInventoryUnits = products.reduce((sum, p) => sum + p.stock, 0);

  // Analytics Chart Data
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    CORE_MILESTONES.forEach((m) => (counts[m] = 0));
    counts['Cancelled'] = 0;
    orders.forEach((o) => {
      counts[o.status] = (counts[o.status] || 0) + 1;
    });
    return Object.entries(counts);
  }, [orders]);

  const maxStatusCount = Math.max(1, ...statusCounts.map(([, v]) => v));

  const categoryRevenue = useMemo(() => {
    const map: Record<string, number> = {};
    products.forEach((p) => {
      map[p.category] = (map[p.category] || 0) + p.price * Math.max(1, Math.min(10, p.stock));
    });
    return Object.entries(map);
  }, [products]);
  const maxCatVal = Math.max(1, ...categoryRevenue.map(([, v]) => v));

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName.trim() || !pSku.trim()) {
      showToast('Product name and SKU are required.', 'error');
      return;
    }
    const productId = `prod-${Date.now()}`;
    await saveProduct(
      {
        productId,
        sku: pSku.trim().toUpperCase(),
        name: pName.trim(),
        category: pCategory,
        description: 'Added via COTS Administrator Catalog Console.',
        price: Number(pPrice) || 4990,
        stock: Number(pStock) || 10,
        imageUrl: DEMO_PRODUCTS[0].imageUrl,
        isActive: true,
      },
      true
    );
    setPName('');
    setPSku('');
  };

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sName.trim() || !sEmail.trim()) {
      showToast('Staff name and email are required.', 'error');
      return;
    }
    await saveStaff({
      uid: sUid.trim() || `staff-${Date.now()}`,
      name: sName.trim(),
      email: sEmail.trim(),
      department: sDept.trim(),
      shift: 'Day (08:00–16:00)',
      isActive: true,
    });
    setSUid('');
    setSName('');
    setSEmail('');
  };

  const handleAddAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aName.trim() || !aEmail.trim()) {
      showToast('Agent name and email are required.', 'error');
      return;
    }
    await saveAgent({
      uid: aUid.trim() || `agent-${Date.now()}`,
      name: aName.trim(),
      email: aEmail.trim(),
      vehicleType: aVehicle.trim(),
      zone: aZone.trim(),
      isActive: true,
    });
    setAUid('');
    setAName('');
    setAEmail('');
  };

  const exportCsvReport = () => {
    const header = ['Order ID', 'Customer', 'City', 'Status', 'Payment', 'Total Amount (INR)', 'Created At'];
    const rows = orders.map((o) => [
      o.orderId,
      `"${o.customerName}"`,
      `"${o.cityRegion}"`,
      o.status,
      o.paymentStatus,
      o.totalAmount.toFixed(2),
      o.createdAt,
    ]);
    const csv = [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cots-orders-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Orders & Revenue CSV report downloaded', 'success');
  };

  const navItems: SidebarNavItem[] = [
    { id: 'analytics', label: 'Analytics & Overview', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'orders', label: 'All Orders', icon: <Package className="w-4 h-4" /> },
    { id: 'products', label: 'Products & Inventory', icon: <Box className="w-4 h-4" /> },
    { id: 'customers', label: 'Customers', icon: <Users className="w-4 h-4" /> },
    { id: 'team', label: 'Staff & Agents', icon: <UserCheck className="w-4 h-4" /> },
  ];

  return (
    <DashboardShell
      requiredRole="admin"
      workspaceTitle="Administrator Console"
      navItems={navItems}
      activeTab={tab}
      onSelectTab={setTab}
    >
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Executive Operations Overview
            </h1>
            <p className="text-sm text-slate-600 mt-0.5">
              Monitor revenue, shipment throughput, inventory health, and role access across COTS.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            {authMode === 'live' && products.length === 0 && (
              <button
                type="button"
                onClick={seedCatalogToFirestore}
                className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                <Database className="w-3.5 h-3.5" />
                Seed Live Firestore Catalog
              </button>
            )}
            <button
              type="button"
              onClick={exportCsvReport}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV Report
            </button>
          </div>
        </div>

        {/* 6-KPI Strip */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Total Revenue</div>
            <div className="text-xl font-bold text-slate-900 mt-1.5">
              <AnimatedCounter value={totalRevenue} prefix="₹" decimals={0} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Total Orders</div>
            <div className="text-xl font-bold text-slate-900 mt-1.5">
              <AnimatedCounter value={orders.length} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Active Shipments</div>
            <div className="text-xl font-bold text-blue-600 mt-1.5">
              <AnimatedCounter value={activeShipments} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Delivered</div>
            <div className="text-xl font-bold text-emerald-700 mt-1.5">
              <AnimatedCounter value={deliveredOrders} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Customers</div>
            <div className="text-xl font-bold text-slate-900 mt-1.5">
              <AnimatedCounter value={customers.length} />
            </div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500">Inventory Units</div>
            <div className="text-xl font-bold text-indigo-600 mt-1.5">
              <AnimatedCounter value={totalInventoryUnits} />
            </div>
          </div>
        </div>

        {tab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Orders by Stage Chart */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
              <h2 className="text-base font-bold text-slate-900">Orders by Fulfillment Stage</h2>
              <p className="text-xs text-slate-500 mt-0.5 mb-6">
                Real-time distribution across the six shipment milestones.
              </p>
              <div className="space-y-3.5">
                {statusCounts.map(([stage, count]) => (
                  <div key={stage} className="space-y-1">
                    <div className="flex justify-between text-xs font-medium">
                      <span className="text-slate-700">{stage}</span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">{count}</span>
                    </div>
                    <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          stage === 'Delivered'
                            ? 'bg-emerald-500'
                            : stage === 'Cancelled'
                              ? 'bg-red-400'
                              : 'bg-blue-600'
                        }`}
                        style={{ width: `${Math.round((count / maxStatusCount) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Inventory Valuation by Category + Recent Activities */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <h2 className="text-base font-bold text-slate-900">Catalog Capacity by Category</h2>
                <p className="text-xs text-slate-500 mt-0.5 mb-5">
                  Active inventory index across product lines.
                </p>
                <div className="space-y-3">
                  {categoryRevenue.map(([cat, val]) => (
                    <div key={cat} className="flex items-center gap-3 text-xs">
                      <span className="w-24 text-slate-600 truncate">{cat}</span>
                      <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-600 rounded-full"
                          style={{ width: `${Math.round((val / maxCatVal) * 100)}%` }}
                        />
                      </div>
                      <span className="w-24 text-right font-mono tabular-nums text-slate-800">
                        {formatINR(Math.round(val))}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <h2 className="text-base font-bold text-slate-900 mb-3">Recent Order Activity</h2>
                <div className="divide-y divide-slate-100">
                  {orders.slice(0, 4).map((o) => (
                    <div key={o.orderId} className="py-2.5 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() => navigateToTrack(o.orderId)}
                          className="font-mono text-xs font-bold text-blue-600 hover:underline cursor-pointer"
                        >
                          {o.orderId}
                        </button>
                        <div className="text-xs text-slate-500 truncate">{o.customerName}</div>
                      </div>
                      <OrderStatusLabel status={o.status} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'orders' && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900">All Orders & Shipment Monitor</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Override any order status or inspect customer payment records ({payments.length} transactions).
                </p>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Payment</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Admin Override</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {orders.map((order) => (
                    <tr key={order.orderId}>
                      <td className="py-3 px-4 font-mono font-semibold">
                        <button
                          type="button"
                          onClick={() => navigateToTrack(order.orderId)}
                          className="text-blue-600 hover:underline cursor-pointer"
                        >
                          {order.orderId}
                        </button>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{order.customerName}</div>
                        <div className="text-xs text-slate-500">{order.cityRegion}</div>
                      </td>
                      <td className="py-3 px-4">
                        <OrderStatusLabel status={order.status} />
                      </td>
                      <td className="py-3 px-4">
                        <PaymentStatusLabel status={order.paymentStatus} />
                      </td>
                      <td className="py-3 px-4 text-right font-semibold tabular-nums">
                        {formatINR(order.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <select
                            value={order.status}
                            onChange={(e) => {
                              const next = e.target.value as OrderStatus;
                              if (next === 'Cancelled') {
                                setCancelTarget({
                                  orderId: order.orderId,
                                  status: order.status,
                                  paymentStatus: order.paymentStatus,
                                  totalAmount: order.totalAmount,
                                  itemCount: order.itemCount,
                                });
                                return;
                              }
                              void updateOrderStatus({
                                orderId: order.orderId,
                                newStatus: next,
                                location: 'Admin Operations Center',
                                description: `Status manually updated to ${next} by Administrator.`,
                              });
                            }}
                            className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-md bg-white"
                          >
                            {[...CORE_MILESTONES, 'Delivery Failed', 'Cancelled'].map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                          {isOrderCancellable(order.status, 'admin') && (
                            <button
                              type="button"
                              onClick={() =>
                                setCancelTarget({
                                  orderId: order.orderId,
                                  status: order.status,
                                  paymentStatus: order.paymentStatus,
                                  totalAmount: order.totalAmount,
                                  itemCount: order.itemCount,
                                })
                              }
                              className="px-2.5 py-1.5 border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium rounded-md transition-colors cursor-pointer"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'products' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-6 h-fit">
              <h2 className="text-base font-bold text-slate-900 mb-4">Add New Product</h2>
              <form onSubmit={handleAddProduct} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Product Name</label>
                  <input
                    type="text"
                    required
                    value={pName}
                    onChange={(e) => setPName(e.target.value)}
                    placeholder="Precision USB-C Hub"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">SKU</label>
                    <input
                      type="text"
                      required
                      value={pSku}
                      onChange={(e) => setPSku(e.target.value)}
                      placeholder="COTS-ACC-701"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
                    <select
                      value={pCategory}
                      onChange={(e) => setPCategory(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="Workspace">Workspace</option>
                      <option value="Audio">Audio</option>
                      <option value="Wearables">Wearables</option>
                      <option value="Peripherals">Peripherals</option>
                      <option value="Carry & Gear">Carry & Gear</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Price (₹)</label>
                    <input
                      type="number"
                      min="1"
                      step="0.01"
                      required
                      value={pPrice}
                      onChange={(e) => setPPrice(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Initial Stock</label>
                    <input
                      type="number"
                      min="0"
                      required
                      value={pStock}
                      onChange={(e) => setPStock(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg tabular-nums"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Create Product
                </button>
              </form>
            </div>

            <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                      <th className="py-3 px-4">SKU</th>
                      <th className="py-3 px-4">Name</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4 text-right">Price</th>
                      <th className="py-3 px-4 text-right">Stock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {products.map((p) => (
                      <tr key={p.productId}>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">{p.sku}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900">{p.name}</td>
                        <td className="py-3 px-4 text-xs text-slate-500">{p.category}</td>
                        <td className="py-3 px-4 text-right tabular-nums">{formatINR(p.price)}</td>
                        <td className="py-3 px-4 text-right font-bold tabular-nums">{p.stock}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'customers' && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900">Registered Customers</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4">Customer Name</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Region</th>
                    <th className="py-3 px-4 text-right">Orders</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {customers.map((c) => (
                    <tr key={c.uid}>
                      <td className="py-3.5 px-4 font-semibold text-slate-900">{c.name}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">{c.email}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-500">{c.cityRegion || '—'}</td>
                      <td className="py-3.5 px-4 text-right font-semibold tabular-nums">{c.totalOrders}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'team' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Staff Management */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
              <h2 className="text-base font-bold text-slate-900">Fulfillment Staff</h2>
              <form onSubmit={handleAddStaff} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={sName}
                  onChange={(e) => setSName(e.target.value)}
                  placeholder="Full Name"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <input
                  type="email"
                  required
                  value={sEmail}
                  onChange={(e) => setSEmail(e.target.value)}
                  placeholder="Staff Email"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <input
                  type="text"
                  value={sUid}
                  onChange={(e) => setSUid(e.target.value)}
                  placeholder="Firebase UID (optional in Demo)"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono"
                />
                <input
                  type="text"
                  value={sDept}
                  onChange={(e) => setSDept(e.target.value)}
                  placeholder="Department"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <button
                  type="submit"
                  className="sm:col-span-2 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Authorize Staff Member
                </button>
              </form>
              <div className="divide-y divide-slate-100">
                {staffList.map((s) => (
                  <div key={s.uid} className="py-3 flex items-center justify-between text-sm">
                    <div>
                      <div className="font-semibold text-slate-900">{s.name}</div>
                      <div className="text-xs text-slate-500">
                        {s.email} · {s.department}
                      </div>
                    </div>
                    <span className="text-xs font-medium text-emerald-700">
                      {s.isActive ? 'Active' : 'Paused'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Delivery Agent Management */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-600" />
                <h2 className="text-base font-bold text-slate-900">Delivery Agents</h2>
              </div>
              <form onSubmit={handleAddAgent} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={aName}
                  onChange={(e) => setAName(e.target.value)}
                  placeholder="Agent Name"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <input
                  type="email"
                  required
                  value={aEmail}
                  onChange={(e) => setAEmail(e.target.value)}
                  placeholder="Agent Email"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <input
                  type="text"
                  value={aUid}
                  onChange={(e) => setAUid(e.target.value)}
                  placeholder="Firebase UID (optional in Demo)"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono"
                />
                <input
                  type="text"
                  value={aZone}
                  onChange={(e) => setAZone(e.target.value)}
                  placeholder="Coverage Zone"
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <input
                  type="text"
                  value={aVehicle}
                  onChange={(e) => setAVehicle(e.target.value)}
                  placeholder="Vehicle Type"
                  className="sm:col-span-2 px-3 py-2 text-sm border border-slate-200 rounded-lg"
                />
                <button
                  type="submit"
                  className="sm:col-span-2 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Authorize Delivery Agent
                </button>
              </form>
              <div className="divide-y divide-slate-100">
                {deliveryAgents.map((a) => (
                  <div key={a.uid} className="py-3 flex items-center justify-between text-sm">
                    <div>
                      <div className="font-semibold text-slate-900">{a.name}</div>
                      <div className="text-xs text-slate-500">
                        {a.zone} · {a.vehicleType}
                      </div>
                    </div>
                    <span className="text-xs font-medium text-emerald-700">
                      {a.isActive ? 'Active' : 'Offline'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <CancelOrderModal
        order={cancelTarget}
        role="admin"
        locationLabel="Admin Operations Center"
        onClose={() => setCancelTarget(null)}
      />
    </DashboardShell>
  );
};
