import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AlertTriangle, CheckCircle2, CreditCard, X, XCircle } from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { formatINR } from '../../lib/currency';
import {
  CUSTOMER_CANCELLATION_REASONS,
  OPS_CANCELLATION_REASONS,
  OrderStatus,
  PaymentStatus,
  UserRole,
  VALIDATION_LIMITS,
} from '../../types/cots';
import { OrderStatusLabel, PaymentStatusLabel } from './StatusBadge';

export interface CancelOrderTarget {
  orderId: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  totalAmount: number;
  itemCount?: number;
}

interface CancelOrderModalProps {
  order: CancelOrderTarget | null;
  role: UserRole;
  locationLabel?: string;
  onClose: () => void;
  onCancelled?: () => void;
}

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  order,
  role,
  locationLabel,
  onClose,
  onCancelled,
}) => {
  const { cancelOrder, showToast } = useCots();

  const presets = role === 'customer' ? CUSTOMER_CANCELLATION_REASONS : OPS_CANCELLATION_REASONS;
  const [selectedReason, setSelectedReason] = useState<string>(presets[0]);
  const [customNote, setCustomNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (order) {
      setSelectedReason(presets[0]);
      setCustomNote('');
      setErrorMsg('');
    }
  }, [order, presets]);

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!order) return;

    const trimmedNote = customNote.trim();
    if (selectedReason === 'Other' && trimmedNote.length < 3) {
      setErrorMsg('Please enter a brief cancellation reason (at least 3 characters).');
      return;
    }

    const finalReason =
      selectedReason === 'Other'
        ? trimmedNote
        : trimmedNote
          ? `${selectedReason} — ${trimmedNote}`
          : selectedReason;

    setSubmitting(true);
    setErrorMsg('');
    try {
      await cancelOrder({
        orderId: order.orderId,
        reason: finalReason.slice(0, VALIDATION_LIMITS.cancellationReasonMax),
        location: locationLabel,
      });
      onCancelled?.();
      onClose();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to cancel order.';
      setErrorMsg(msg);
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {order && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 bg-slate-900/45 backdrop-blur-[2px] flex items-center justify-center p-4"
          onClick={() => !submitting && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="cancel-order-title"
            className="bg-white border border-slate-200 rounded-2xl shadow-xl max-w-lg w-full overflow-hidden"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-50 border border-red-100 text-red-600 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h2 id="cancel-order-title" className="text-base font-bold text-slate-900">
                    Cancel Order
                  </h2>
                  <p className="text-xs font-mono text-slate-500">{order.orderId}</p>
                </div>
              </div>
              <button
                type="button"
                disabled={submitting}
                onClick={onClose}
                aria-label="Close cancel modal"
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirm} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Order Summary Strip */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-xs text-slate-500">Current Stage</div>
                  <OrderStatusLabel status={order.status} />
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-slate-500">Payment</div>
                  <PaymentStatusLabel status={order.paymentStatus} />
                </div>
                <div className="text-right space-y-0.5">
                  <div className="text-xs text-slate-500">
                    Order Total{order.itemCount ? ` (${order.itemCount} items)` : ''}
                  </div>
                  <div className="text-base font-bold text-slate-900 tabular-nums">
                    {formatINR(order.totalAmount)}
                  </div>
                </div>
              </div>

              {/* Refund Notice */}
              {order.paymentStatus === 'Paid' ? (
                <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-start gap-2.5 text-xs text-emerald-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Automatic Refund Eligibility:</span> Your prepaid
                    amount of <span className="font-bold tabular-nums">{formatINR(order.totalAmount)}</span>{' '}
                    will be marked as <span className="font-semibold">Refunded</span> immediately in
                    your order and payment records.
                  </div>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5 text-xs text-slate-700">
                  <CreditCard className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">No Payment Collected:</span> Since this order is
                    pending payment (Cash on Delivery), cancelling removes the pending fulfillment
                    with no refund required.
                  </div>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
                  {errorMsg}
                </div>
              )}

              {/* Cancellation Reason Selection */}
              <div className="space-y-2.5">
                <label className="block text-xs font-semibold text-slate-800">
                  Select a reason for cancellation
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {presets.map((reason) => {
                    const active = selectedReason === reason;
                    return (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => setSelectedReason(reason)}
                        className={`text-left px-3 py-2.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                          active
                            ? 'border-blue-600 bg-blue-50/70 text-blue-900'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {reason}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Optional / Custom Details */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {selectedReason === 'Other'
                    ? 'Please describe your reason (required)'
                    : 'Additional notes (optional)'}
                </label>
                <textarea
                  rows={2}
                  maxLength={200}
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  placeholder={
                    selectedReason === 'Other'
                      ? 'Tell us why you would like to cancel this order...'
                      : 'Optional note for the shipment log...'
                  }
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 resize-none"
                />
              </div>

              {/* Footer Actions */}
              <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-end gap-2.5">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={onClose}
                  className="w-full sm:w-auto px-4 py-2.5 border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Keep Order
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  {submitting ? 'Cancelling Order...' : 'Confirm Cancellation'}
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
