import React from 'react';

export const TableRowSkeleton: React.FC<{ rows?: number }> = ({ rows = 4 }) => (
  <div className="divide-y divide-slate-100">
    {Array.from({ length: rows }).map((_, i) => (
      <div key={i} className="flex items-center justify-between py-3.5 px-4 animate-pulse">
        <div className="flex items-center gap-4">
          <div className="h-4 w-28 bg-slate-200 rounded" />
          <div className="h-4 w-36 bg-slate-100 rounded" />
        </div>
        <div className="flex items-center gap-4">
          <div className="h-4 w-20 bg-slate-100 rounded" />
          <div className="h-7 w-20 bg-slate-200 rounded-md" />
        </div>
      </div>
    ))}
  </div>
);

export const TrackingSkeleton: React.FC = () => (
  <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 animate-pulse space-y-6">
    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-6">
      <div className="space-y-2">
        <div className="h-4 w-24 bg-slate-200 rounded" />
        <div className="h-7 w-48 bg-slate-200 rounded" />
      </div>
      <div className="h-9 w-36 bg-slate-100 rounded-lg" />
    </div>
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="space-y-2">
          <div className="h-3 w-20 bg-slate-100 rounded" />
          <div className="h-5 w-32 bg-slate-200 rounded" />
        </div>
      ))}
    </div>
    <div className="h-24 w-full bg-slate-100 rounded-xl" />
  </div>
);
