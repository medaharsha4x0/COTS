import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { formatINR } from '../../lib/currency';
import { PaymentMethod } from '../../types/cots';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    cartOpen,
    setCartOpen,
    updateCartQty,
    removeFromCart,
    placeOrder,
    authMode,
    activeUserName,
    customerProfile,
    setAuthModalOpen,
    navigateToTrack,
    showToast,
  } = useCots();

  const [customerName, setCustomerName] = useState(activeUserName || '');
  const [phone, setPhone] = useState(customerProfile?.phone || '');
  const [deliveryAddress, setDeliveryAddress] = useState(customerProfile?.defaultAddress || '');
  const [cityRegion, setCityRegion] = useState(customerProfile?.cityRegion || '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Card');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (customerProfile) {
      setCustomerName(customerProfile.name || activeUserName);
      setPhone(customerProfile.phone || '');
      setDeliveryAddress(customerProfile.defaultAddress || '');
      setCityRegion(customerProfile.cityRegion || '');
    } else if (activeUserName) {
      setCustomerName(activeUserName);
    }
  }, [customerProfile, activeUserName]);

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (authMode === 'guest') {
      setCartOpen(false);
      setAuthModalOpen(true);
      showToast('Please sign in or choose Demo Customer to place an order.', 'info');
      return;
    }

    if (customerName.trim().length < 2) {
      setFormError('Please enter the recipient full name.');
      return;
    }
    if (deliveryAddress.trim().length < 5) {
      setFormError('Please enter a valid street delivery address (at least 5 characters).');
      return;
    }
    if (cityRegion.trim().length < 2) {
      setFormError('Please enter your city and state/region.');
      return;
    }

    setSubmitting(true);
    try {
      const orderId = await placeOrder({
        customerName: customerName.trim(),
        phone: phone.trim() || '+1 (555) 010-0000',
        deliveryAddress: deliveryAddress.trim(),
        cityRegion: cityRegion.trim(),
        paymentMethod,
      });
      navigateToTrack(orderId);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to place order.';
      setFormError(msg);
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {cartOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[2px] flex justify-end"
          onClick={() => setCartOpen(false)}
        >
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
                <h2 className="text-base font-bold text-slate-900">
                  Order Cart ({cart.reduce((s, i) => s + i.quantity, 0)})
                </h2>
              </div>
              <button
                onClick={() => setCartOpen(false)}
                aria-label="Close cart"
                className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cart.length === 0 ? (
                <div className="py-16 text-center">
                  <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm font-semibold text-slate-900">Your cart is empty</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Add products from the catalog to generate a tracked order.
                  </p>
                </div>
              ) : (
                <>
                  <div className="divide-y divide-slate-100">
                    {cart.map((item) => (
                      <div key={item.product.productId} className="py-3.5 flex gap-3.5">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-lg object-cover border border-slate-200 shrink-0 bg-slate-100"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm font-semibold text-slate-900 truncate">
                            {item.product.name}
                          </h3>
                          <div className="text-xs text-slate-500 tabular-nums mt-0.5">
                            {formatINR(item.product.price)} each · {item.product.stock} in stock
                          </div>
                          <div className="flex items-center justify-between mt-2.5">
                            <div className="inline-flex items-center border border-slate-200 rounded-lg">
                              <button
                                type="button"
                                onClick={() =>
                                  updateCartQty(item.product.productId, item.quantity - 1)
                                }
                                className="p-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                                aria-label="Decrease quantity"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="px-2.5 text-xs font-semibold tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  updateCartQty(item.product.productId, item.quantity + 1)
                                }
                                className="p-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                                aria-label="Increase quantity"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeFromCart(item.product.productId)}
                              className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                              aria-label="Remove item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <form id="checkout-form" onSubmit={handleCheckout} className="space-y-4 pt-4 border-t border-slate-200">
                    <h3 className="text-sm font-bold text-slate-900">Delivery & Payment</h3>

                    {formError && (
                      <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
                        {formError}
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Recipient Full Name
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={120}
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Clara Vance"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          maxLength={32}
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+1 (415) 555-0194"
                          className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          City / Region
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={120}
                          value={cityRegion}
                          onChange={(e) => setCityRegion(e.target.value)}
                          placeholder="San Francisco, CA"
                          className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Street Delivery Address
                      </label>
                      <textarea
                        rows={2}
                        required
                        maxLength={300}
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="742 Evergreen Terrace, Suite 4B, San Francisco, CA 94107"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Payment Method
                      </label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                      >
                        <option value="Card">Credit / Debit Card</option>
                        <option value="UPI">UPI Instant Pay</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Cash on Delivery">Cash on Delivery</option>
                      </select>
                    </div>
                  </form>
                </>
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-slate-200 bg-slate-50 space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">Total Amount</span>
                  <span className="text-lg font-bold text-slate-900 tabular-nums">
                    {formatINR(subtotal)}
                  </span>
                </div>
                <button
                  type="submit"
                  form="checkout-form"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm cursor-pointer"
                >
                  {submitting ? 'Placing Order...' : authMode === 'guest' ? 'Sign In to Place Order' : 'Place Order & Generate Tracking ID'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
