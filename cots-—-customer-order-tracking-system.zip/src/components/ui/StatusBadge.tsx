import React from 'react';
import {
  AlertCircle,
  Box,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Truck,
  XCircle,
} from 'lucide-react';
import { OrderStatus, PaymentStatus } from '../../types/cots';

export const OrderStatusLabel: React.FC<{ status: OrderStatus }> = ({ status }) => {
  const config: Record<
    OrderStatus,
    { icon: React.ReactNode; color: string }
  > = {
    'Order Placed': {
      icon: <Clock className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-slate-700',
    },
    'Order Confirmed': {
      icon: <ClipboardCheck className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-blue-700',
    },
    Packed: {
      icon: <Box className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-indigo-700',
    },
    Shipped: {
      icon: <Truck className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-blue-700',
    },
    'Out for Delivery': {
      icon: <Truck className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-blue-600',
    },
    Delivered: {
      icon: <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-emerald-700',
    },
    'Delivery Failed': {
      icon: <AlertCircle className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-amber-700',
    },
    Cancelled: {
      icon: <XCircle className="w-3.5 h-3.5 shrink-0" />,
      color: 'text-red-700',
    },
  };

  const entry = config[status] || config['Order Placed'];

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${entry.color}`}>
      {entry.icon}
      <span>{status}</span>
    </span>
  );
};

export const PaymentStatusLabel: React.FC<{ status: PaymentStatus }> = ({ status }) => {
  const styles: Record<PaymentStatus, string> = {
    Paid: 'text-emerald-700',
    Pending: 'text-amber-700',
    Refunded: 'text-slate-600',
  };

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${styles[status]}`}>
      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
      <span>{status}</span>
    </span>
  );
};
