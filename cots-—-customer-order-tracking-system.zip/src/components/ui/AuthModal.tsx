import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Package, Shield, Truck, UserCheck, Users, X } from 'lucide-react';
import { useCots } from '../../context/CotsContext';
import { UserRole } from '../../types/cots';

export const AuthModal: React.FC = () => {
  const { authModalOpen, setAuthModalOpen, signInWithGoogle, enterDemoMode } = useCots();

  const demoRoles: Array<{
    role: UserRole;
    title: string;
    desc: string;
    icon: React.ReactNode;
  }> = [
    {
      role: 'customer',
      title: 'Customer Portal',
      desc: 'Browse products, place orders, track shipments, and manage profile.',
      icon: <Users className="w-4 h-4 text-blue-600" />,
    },
    {
      role: 'staff',
      title: 'Fulfillment Staff',
      desc: 'Confirm orders, manage packing, assign couriers, and update stock.',
      icon: <Package className="w-4 h-4 text-indigo-600" />,
    },
    {
      role: 'delivery_agent',
      title: 'Delivery Agent',
      desc: 'View assigned dispatches and log Out for Delivery or Delivered updates.',
      icon: <Truck className="w-4 h-4 text-blue-600" />,
    },
    {
      role: 'admin',
      title: 'System Administrator',
      desc: 'Revenue analytics, customer/staff/agent management, and CSV reports.',
      icon: <Shield className="w-4 h-4 text-indigo-600" />,
    },
  ];

  return (
    <AnimatePresence>
      {authModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center p-4"
          onClick={() => setAuthModalOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.98 }}
            transition={{ duration: 0.18 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white border border-slate-200 rounded-2xl shadow-xl max-w-lg w-full overflow-hidden"
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Sign in to COTS</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Connect your Google account for live Cloud Firestore persistence or explore a role sandbox.
                </p>
              </div>
              <button
                onClick={() => setAuthModalOpen(false)}
                aria-label="Close sign in dialog"
                className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-2.5">
                  Production Account · Live Cloud Persistence
                </div>
                <button
                  onClick={signInWithGoogle}
                  className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  Continue with Google
                </button>
                <p className="text-xs text-slate-500 mt-2">
                  New accounts register automatically as verified Customers with role-protected Firestore access.
                </p>
              </div>

              <div className="border-t border-slate-100 pt-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-slate-500">
                    Interactive Demonstration Sandbox · Sample Data
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {demoRoles.map((item) => (
                    <button
                      key={item.role}
                      onClick={() => enterDemoMode(item.role)}
                      className="text-left p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {item.icon}
                        <span className="text-sm font-semibold text-slate-900 group-hover:text-blue-700">
                          {item.title}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
