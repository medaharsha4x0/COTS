import React, { useState } from 'react';
import { Menu, PackageCheck, ShoppingBag, X } from 'lucide-react';
import { useCots } from '../context/CotsContext';
import { AppView } from '../types/cots';

export const Navbar: React.FC = () => {
  const {
    view,
    setView,
    authMode,
    userRole,
    setAuthModalOpen,
    cart,
    setCartOpen,
  } = useCots();

  const [mobileOpen, setMobileOpen] = useState(false);

  const dashboardView: AppView =
    userRole === 'admin'
      ? 'admin-dashboard'
      : userRole === 'staff'
        ? 'staff-dashboard'
        : userRole === 'delivery_agent'
          ? 'agent-dashboard'
          : 'customer-dashboard';

  const cartCount = cart.reduce((s, c) => s + c.quantity, 0);

  const navigate = (target: AppView) => {
    setView(target);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          onClick={() => navigate('landing')}
          className="inline-flex items-center gap-2.5 text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <span className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
            <PackageCheck className="w-4 h-4" />
          </span>
          <span className="font-display">COTS</span>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            onClick={() => navigate('landing')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1 ${
              view === 'landing' ? 'text-blue-600 font-semibold' : ''
            }`}
          >
            Home
          </button>
          <button
            onClick={() => navigate('track')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1 ${
              view === 'track' ? 'text-blue-600 font-semibold' : ''
            }`}
          >
            Track Order
          </button>
          <button
            onClick={() => navigate('products')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1 ${
              view === 'products' ? 'text-blue-600 font-semibold' : ''
            }`}
          >
            Products
          </button>
          <button
            onClick={() => {
              if (view !== 'landing') {
                setView('landing');
                setTimeout(() => {
                  document.getElementById('about-cots')?.scrollIntoView({ behavior: 'smooth' });
                }, 80);
              } else {
                document.getElementById('about-cots')?.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1"
          >
            About Us
          </button>
          {authMode === 'guest' ? (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1"
            >
              Login
            </button>
          ) : (
            <button
              onClick={() => setCartOpen(true)}
              className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors cursor-pointer py-1"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Cart ({cartCount})</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          {authMode === 'guest' ? (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="hidden sm:inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Get Started
            </button>
          ) : (
            <button
              onClick={() => navigate(dashboardView)}
              className="hidden sm:inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Open Dashboard
            </button>
          )}

          <button
            onClick={() => setMobileOpen((p) => !p)}
            aria-label="Toggle navigation menu"
            className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2">
          <button
            onClick={() => navigate('landing')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
          >
            Home
          </button>
          <button
            onClick={() => navigate('track')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
          >
            Track Order
          </button>
          <button
            onClick={() => navigate('products')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
          >
            Products
          </button>
          <button
            onClick={() => {
              setCartOpen(true);
              setMobileOpen(false);
            }}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
          >
            Cart ({cartCount})
          </button>
          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            {authMode === 'guest' ? (
              <button
                onClick={() => {
                  setAuthModalOpen(true);
                  setMobileOpen(false);
                }}
                className="w-full py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg"
              >
                Login / Get Started
              </button>
            ) : (
              <button
                onClick={() => navigate(dashboardView)}
                className="w-full py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg"
              >
                Open Dashboard
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
