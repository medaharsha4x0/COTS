import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import {
  DEMO_CUSTOMERS,
  DEMO_DELIVERY_AGENTS,
  DEMO_ORDERS,
  DEMO_PAYMENTS,
  DEMO_PRODUCTS,
  DEMO_STAFF,
  DEMO_TRACKING_RECORDS,
} from '../data/demoData';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  cancelLiveOrder,
  fetchAllAgentsLive,
  fetchAllCustomersLive,
  fetchAllPaymentsLive,
  fetchAllStaffLive,
  fetchOrderItemsLive,
  fetchOrderTrackingLive,
  fetchProductsLive,
  formatTimestamp,
  generateUniqueOrderId,
  placeLiveOrder,
  resolveUserRole,
  seedLiveProducts,
  syncCustomerProfile,
  updateCustomerProfileLive,
  updateLiveOrderStatus,
  updateLiveProductStock,
  upsertAgentLive,
  upsertLiveProduct,
  upsertStaffLive,
} from '../services/cotsService';
import {
  AppView,
  CartItem,
  CustomerProfile,
  DeliveryAgent,
  Order,
  OrderStatus,
  OrderTrackingRecord,
  PaymentMethod,
  PaymentRecord,
  Product,
  StaffMember,
  UserRole,
} from '../types/cots';

export interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export type AuthMode = 'guest' | 'demo' | 'live';

interface CotsContextValue {
  view: AppView;
  setView: (v: AppView) => void;
  navigateToTrack: (orderId?: string) => void;
  activeTrackingId: string;
  setActiveTrackingId: (id: string) => void;

  authReady: boolean;
  authMode: AuthMode;
  firebaseUser: User | null;
  userRole: UserRole;
  activeUserName: string;
  activeUserEmail: string;
  activeUid: string;
  customerProfile: CustomerProfile | null;

  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  signInWithGoogle: () => Promise<void>;
  enterDemoMode: (role: UserRole) => void;
  logout: () => Promise<void>;

  products: Product[];
  orders: Order[];
  customers: CustomerProfile[];
  staffList: StaffMember[];
  deliveryAgents: DeliveryAgent[];
  payments: PaymentRecord[];
  dataLoading: boolean;

  cart: CartItem[];
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  addToCart: (product: Product, qty?: number) => void;
  updateCartQty: (productId: string, qty: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;

  toasts: ToastItem[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;

  // Core Actions
  trackOrder: (orderId: string) => Promise<OrderTrackingRecord | null>;
  placeOrder: (payload: {
    customerName: string;
    phone: string;
    deliveryAddress: string;
    cityRegion: string;
    paymentMethod: PaymentMethod;
  }) => Promise<string>;
  updateOrderStatus: (payload: {
    orderId: string;
    newStatus: OrderStatus;
    location: string;
    description: string;
    assignedAgentUid?: string;
    assignedAgentName?: string;
  }) => Promise<void>;
  cancelOrder: (payload: {
    orderId: string;
    reason: string;
    location?: string;
  }) => Promise<void>;
  updateProfile: (updates: {
    name: string;
    phone: string;
    defaultAddress: string;
    cityRegion: string;
  }) => Promise<void>;
  updateProductStock: (productId: string, newStock: number) => Promise<void>;
  saveProduct: (product: Omit<Product, 'createdAt' | 'updatedAt'>, isNew: boolean) => Promise<void>;
  saveStaff: (staff: Omit<StaffMember, 'createdAt'>) => Promise<void>;
  saveAgent: (agent: Omit<DeliveryAgent, 'createdAt'>) => Promise<void>;
  seedCatalogToFirestore: () => Promise<void>;
  loadOrderItems: (orderId: string) => Promise<void>;
}

const CotsContext = createContext<CotsContextValue | null>(null);

export const CotsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [view, setView] = useState<AppView>('landing');
  const [activeTrackingId, setActiveTrackingId] = useState<string>('COTS-2026-1042');

  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<AuthMode>('guest');
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<UserRole>('customer');
  const [customerProfile, setCustomerProfile] = useState<CustomerProfile | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Demo sandbox mutable state
  const [demoProducts, setDemoProducts] = useState<Product[]>(DEMO_PRODUCTS);
  const [demoOrders, setDemoOrders] = useState<Order[]>(DEMO_ORDERS);
  const [demoTrackingMap, setDemoTrackingMap] = useState<Record<string, OrderTrackingRecord>>(
    DEMO_TRACKING_RECORDS
  );
  const [demoCustomers, setDemoCustomers] = useState<CustomerProfile[]>(DEMO_CUSTOMERS);
  const [demoStaff, setDemoStaff] = useState<StaffMember[]>(DEMO_STAFF);
  const [demoAgents, setDemoAgents] = useState<DeliveryAgent[]>(DEMO_DELIVERY_AGENTS);
  const [demoPayments, setDemoPayments] = useState<PaymentRecord[]>(DEMO_PAYMENTS);

  // Live Firestore state
  const [liveProducts, setLiveProducts] = useState<Product[]>([]);
  const [liveOrders, setLiveOrders] = useState<Order[]>([]);
  const [liveCustomers, setLiveCustomers] = useState<CustomerProfile[]>([]);
  const [liveStaff, setLiveStaff] = useState<StaffMember[]>([]);
  const [liveAgents, setLiveAgents] = useState<DeliveryAgent[]>([]);
  const [livePayments, setLivePayments] = useState<PaymentRecord[]>([]);
  const [dataLoading, setDataLoading] = useState(false);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const showToast = useCallback(
    (message: string, type: 'success' | 'error' | 'info' = 'success') => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4200);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Load initial public products (from Firestore if seeded, else fallback to Demo catalog)
  useEffect(() => {
    let active = true;
    fetchProductsLive(false)
      .then((items) => {
        if (!active) return;
        if (items.length > 0) {
          setLiveProducts(items);
        }
      })
      .catch(() => {
        // Storefront safely continues with demonstration catalog if Firestore catalog is not yet seeded
      });
    return () => {
      active = false;
    };
  }, []);

  // Auth State Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        setAuthMode('live');
        try {
          const role = await resolveUserRole(user);
          setUserRole(role);
          const profile = await syncCustomerProfile(user);
          setCustomerProfile(profile);
        } catch (err) {
          console.error('Auth sync error:', err);
        }
      } else {
        setAuthMode((prev) => (prev === 'demo' ? 'demo' : 'guest'));
        setCustomerProfile(null);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  // Attach Firestore real-time listeners ONLY when authenticated in live mode
  useEffect(() => {
    if (!authReady || authMode !== 'live' || !firebaseUser) return;

    setDataLoading(true);
    const unsubs: Array<() => void> = [];

    // Orders listener matching security rules
    const ordersQuery =
      userRole === 'customer'
        ? query(collection(db, 'orders'), where('customerUid', '==', firebaseUser.uid))
        : collection(db, 'orders');

    const unsubOrders = onSnapshot(
      ordersQuery,
      (snap) => {
        const list: Order[] = snap.docs
          .map((d) => {
            const o = d.data();
            return {
              orderId: o.orderId,
              customerUid: o.customerUid,
              customerName: o.customerName,
              customerEmail: o.customerEmail,
              phone: o.phone || '',
              deliveryAddress: o.deliveryAddress,
              cityRegion: o.cityRegion,
              status: o.status as OrderStatus,
              paymentStatus: o.paymentStatus,
              totalAmount: Number(o.totalAmount),
              itemCount: Number(o.itemCount),
              expectedDelivery: o.expectedDelivery,
              assignedAgentUid: o.assignedAgentUid,
              assignedAgentName: o.assignedAgentName,
              cancellationReason: o.cancellationReason || undefined,
              isDemo: Boolean(o.isDemo),
              createdAt: formatTimestamp(o.createdAt),
              updatedAt: formatTimestamp(o.updatedAt),
            };
          })
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setLiveOrders(list);
        setDataLoading(false);
      },
      (error) => {
        setDataLoading(false);
        handleFirestoreError(error, OperationType.LIST, 'orders');
      }
    );
    unsubs.push(unsubOrders);

    // Products listener
    const productsQuery =
      userRole === 'admin' || userRole === 'staff'
        ? collection(db, 'products')
        : query(collection(db, 'products'), where('isActive', '==', true));

    const unsubProducts = onSnapshot(
      productsQuery,
      (snap) => {
        const items: Product[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            productId: data.productId,
            sku: data.sku,
            name: data.name,
            category: data.category,
            description: data.description || '',
            price: Number(data.price),
            stock: Number(data.stock),
            imageUrl: data.imageUrl,
            isActive: Boolean(data.isActive),
            createdAt: formatTimestamp(data.createdAt),
            updatedAt: formatTimestamp(data.updatedAt),
          };
        });
        setLiveProducts(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'products');
      }
    );
    unsubs.push(unsubProducts);

    // Role-specific collections
    if (userRole === 'admin') {
      fetchAllCustomersLive().then(setLiveCustomers).catch(console.error);
      fetchAllStaffLive().then(setLiveStaff).catch(console.error);
      fetchAllAgentsLive().then(setLiveAgents).catch(console.error);
      fetchAllPaymentsLive().then(setLivePayments).catch(console.error);
    } else if (userRole === 'staff') {
      fetchAllAgentsLive().then(setLiveAgents).catch(console.error);
    }

    return () => {
      unsubs.forEach((fn) => fn());
    };
  }, [authReady, authMode, firebaseUser, userRole]);

  const signInWithGoogle = useCallback(async () => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const role = await resolveUserRole(cred.user);
      setAuthMode('live');
      setUserRole(role);
      setAuthModalOpen(false);
      showToast(`Signed in as ${cred.user.displayName || cred.user.email}`, 'success');
      if (role === 'admin') setView('admin-dashboard');
      else if (role === 'staff') setView('staff-dashboard');
      else if (role === 'delivery_agent') setView('agent-dashboard');
      else setView('customer-dashboard');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      showToast(msg, 'error');
    }
  }, [showToast]);

  const enterDemoMode = useCallback(
    (role: UserRole) => {
      setAuthMode('demo');
      setUserRole(role);
      setAuthModalOpen(false);
      if (role === 'customer') {
        setCustomerProfile(demoCustomers[0]);
        setView('customer-dashboard');
      } else if (role === 'staff') {
        setView('staff-dashboard');
      } else if (role === 'delivery_agent') {
        setView('agent-dashboard');
      } else {
        setView('admin-dashboard');
      }
      const roleLabel =
        role === 'delivery_agent'
          ? 'Delivery Agent'
          : role.charAt(0).toUpperCase() + role.slice(1);
      showToast(`Entered Demo Sandbox as ${roleLabel}`, 'info');
    },
    [demoCustomers, showToast]
  );

  const logout = useCallback(async () => {
    if (firebaseUser) {
      await signOut(auth);
    }
    setAuthMode('guest');
    setUserRole('customer');
    setCustomerProfile(null);
    setView('landing');
    showToast('Signed out', 'info');
  }, [firebaseUser, showToast]);

  const navigateToTrack = useCallback((orderId?: string) => {
    if (orderId) {
      setActiveTrackingId(orderId.trim().toUpperCase());
    }
    setView('track');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Derived active lists (Live Firestore vs Demo Sandbox)
  const products =
    authMode === 'live'
      ? liveProducts
      : liveProducts.length > 0 && authMode === 'guest'
        ? liveProducts
        : demoProducts;

  const orders = authMode === 'live' ? liveOrders : demoOrders;
  const customers = authMode === 'live' ? liveCustomers : demoCustomers;
  const staffList = authMode === 'live' ? liveStaff : demoStaff;
  const deliveryAgents = authMode === 'live' ? liveAgents : demoAgents;
  const payments = authMode === 'live' ? livePayments : demoPayments;

  const activeUid =
    authMode === 'live' && firebaseUser
      ? firebaseUser.uid
      : userRole === 'customer'
        ? demoCustomers[0].uid
        : userRole === 'staff'
          ? demoStaff[0].uid
          : userRole === 'delivery_agent'
            ? demoAgents[0].uid
            : 'demo-admin-01';

  const activeUserName =
    authMode === 'live' && firebaseUser
      ? customerProfile?.name || firebaseUser.displayName || 'Account User'
      : userRole === 'customer'
        ? demoCustomers[0].name
        : userRole === 'staff'
          ? demoStaff[0].name
          : userRole === 'delivery_agent'
            ? demoAgents[0].name
            : 'Operations Administrator';

  const activeUserEmail =
    authMode === 'live' && firebaseUser
      ? firebaseUser.email || ''
      : userRole === 'customer'
        ? demoCustomers[0].email
        : userRole === 'staff'
          ? demoStaff[0].email
          : userRole === 'delivery_agent'
            ? demoAgents[0].email
            : 'admin@cots-logistics.demo';

  // Cart Handlers
  const addToCart = useCallback(
    (product: Product, qty = 1) => {
      if (product.stock <= 0) {
        showToast(`${product.name} is currently out of stock.`, 'error');
        return;
      }
      setCart((prev) => {
        const existing = prev.find((i) => i.product.productId === product.productId);
        if (existing) {
          const nextQty = Math.min(product.stock, existing.quantity + qty);
          return prev.map((i) =>
            i.product.productId === product.productId ? { ...i, quantity: nextQty } : i
          );
        }
        return [...prev, { product, quantity: Math.min(product.stock, qty) }];
      });
      showToast(`Added ${product.name} to cart`, 'success');
    },
    [showToast]
  );

  const updateCartQty = useCallback((productId: string, qty: number) => {
    setCart((prev) =>
      qty <= 0
        ? prev.filter((i) => i.product.productId !== productId)
        : prev.map((i) =>
            i.product.productId === productId
              ? { ...i, quantity: Math.min(i.product.stock, qty) }
              : i
          )
    );
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart((prev) => prev.filter((i) => i.product.productId !== productId));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  // Track Order (supports both Live Firestore & Demo records seamlessly)
  const trackOrder = useCallback(
    async (orderId: string): Promise<OrderTrackingRecord | null> => {
      const normalized = orderId.trim().toUpperCase();
      if (!normalized) return null;

      // Check local demo records first if in demo mode or if ID starts with demo ID
      if (authMode !== 'live' && demoTrackingMap[normalized]) {
        return demoTrackingMap[normalized];
      }

      // Query Firestore live projection
      const hasFullAccess = authMode === 'live' && Boolean(firebaseUser);
      const liveRecord = await fetchOrderTrackingLive(normalized, hasFullAccess);
      if (liveRecord) return liveRecord;

      // Fallback to demo tracking records so homepage visitors can always track sample IDs
      if (demoTrackingMap[normalized]) {
        return demoTrackingMap[normalized];
      }

      return null;
    },
    [authMode, demoTrackingMap, firebaseUser]
  );

  const placeOrder = useCallback(
    async (payload: {
      customerName: string;
      phone: string;
      deliveryAddress: string;
      cityRegion: string;
      paymentMethod: PaymentMethod;
    }): Promise<string> => {
      if (cart.length === 0) throw new Error('Your cart is empty.');

      if (authMode === 'live' && firebaseUser) {
        const orderId = await placeLiveOrder({
          user: firebaseUser,
          customerProfile,
          cart,
          ...payload,
        });
        clearCart();
        setCartOpen(false);
        showToast(`Order ${orderId} placed successfully!`, 'success');
        return orderId;
      }

      // Demo Sandbox Order Placement
      const orderId = generateUniqueOrderId();
      const nowIso = new Date().toISOString();
      const totalAmount = Number(
        cart.reduce((s, i) => s + i.product.price * i.quantity, 0).toFixed(2)
      );
      const itemCount = cart.reduce((s, i) => s + i.quantity, 0);
      const expectedDelivery = new Date(Date.now() + 4 * 86400000).toLocaleDateString(
        'en-US',
        { month: 'short', day: 'numeric', year: 'numeric' }
      );
      const paymentStatus = payload.paymentMethod === 'Cash on Delivery' ? 'Pending' : 'Paid';

      const orderItems = cart.map((c, idx) => ({
        orderItemId: `item-${Date.now()}-${idx + 1}`,
        orderId,
        customerUid: activeUid,
        productId: c.product.productId,
        productName: c.product.name,
        productImage: c.product.imageUrl,
        quantity: c.quantity,
        unitPrice: c.product.price,
        subtotal: Number((c.product.price * c.quantity).toFixed(2)),
      }));

      const newOrder: Order = {
        orderId,
        customerUid: activeUid,
        customerName: payload.customerName,
        customerEmail: activeUserEmail,
        phone: payload.phone,
        deliveryAddress: payload.deliveryAddress,
        cityRegion: payload.cityRegion,
        status: 'Order Placed',
        paymentStatus,
        totalAmount,
        itemCount,
        expectedDelivery,
        isDemo: true,
        createdAt: nowIso,
        updatedAt: nowIso,
        items: orderItems,
      };

      const initialHistory = {
        trackingId: `trk-${Date.now()}`,
        orderId,
        status: 'Order Placed' as OrderStatus,
        location: 'Online Checkout · COTS Demo Storefront',
        description: `Order placed via ${payload.paymentMethod} (${paymentStatus}).`,
        updatedByUid: activeUid,
        updatedByRole: 'customer' as UserRole,
        timestamp: nowIso,
      };

      const newTrack: OrderTrackingRecord = {
        orderId,
        customerUid: activeUid,
        currentStatus: 'Order Placed',
        paymentStatus,
        cityRegion: payload.cityRegion,
        expectedDelivery,
        totalAmount,
        itemSummary: cart
          .map((c) => (c.quantity > 1 ? `${c.product.name} (x${c.quantity})` : c.product.name))
          .join(', '),
        itemCount,
        isDemo: true,
        createdAt: nowIso,
        updatedAt: nowIso,
        deliveryAddress: payload.deliveryAddress,
        customerName: payload.customerName,
        items: orderItems,
        history: [initialHistory],
      };

      setDemoProducts((prev) =>
        prev.map((p) => {
          const ordered = cart.find((c) => c.product.productId === p.productId);
          return ordered ? { ...p, stock: Math.max(0, p.stock - ordered.quantity) } : p;
        })
      );
      setDemoOrders((prev) => [newOrder, ...prev]);
      setDemoTrackingMap((prev) => ({ ...prev, [orderId]: newTrack }));
      setDemoPayments((prev) => [
        {
          paymentId: `pay-${Date.now()}`,
          orderId,
          customerUid: activeUid,
          amount: totalAmount,
          method: payload.paymentMethod,
          status: paymentStatus,
          transactionRef: `TXN-DEMO-${Math.floor(10000 + Math.random() * 90000)}`,
          createdAt: nowIso,
        },
        ...prev,
      ]);

      clearCart();
      setCartOpen(false);
      showToast(`Demo Order ${orderId} placed!`, 'success');
      return orderId;
    },
    [
      activeUid,
      activeUserEmail,
      authMode,
      cart,
      clearCart,
      customerProfile,
      firebaseUser,
      showToast,
    ]
  );

  const updateOrderStatus = useCallback(
    async (payload: {
      orderId: string;
      newStatus: OrderStatus;
      location: string;
      description: string;
      assignedAgentUid?: string;
      assignedAgentName?: string;
    }) => {
      if (authMode === 'live' && firebaseUser) {
        await updateLiveOrderStatus({
          ...payload,
          updatedByUid: firebaseUser.uid,
          updatedByRole: userRole,
        });
        showToast(`Order ${payload.orderId} updated to ${payload.newStatus}`, 'success');
        return;
      }

      const nowIso = new Date().toISOString();
      setDemoOrders((prev) =>
        prev.map((o) =>
          o.orderId === payload.orderId
            ? {
                ...o,
                status: payload.newStatus,
                updatedAt: nowIso,
                assignedAgentUid: payload.assignedAgentUid ?? o.assignedAgentUid,
                assignedAgentName: payload.assignedAgentName ?? o.assignedAgentName,
              }
            : o
        )
      );

      setDemoTrackingMap((prev) => {
        const existing = prev[payload.orderId];
        if (!existing) return prev;
        return {
          ...prev,
          [payload.orderId]: {
            ...existing,
            currentStatus: payload.newStatus,
            updatedAt: nowIso,
            history: [
              ...existing.history,
              {
                trackingId: `trk-${Date.now()}`,
                orderId: payload.orderId,
                status: payload.newStatus,
                location: payload.location,
                description: payload.description,
                updatedByUid: activeUid,
                updatedByRole: userRole,
                timestamp: nowIso,
              },
            ],
          },
        };
      });

      showToast(`Order ${payload.orderId} updated to ${payload.newStatus}`, 'success');
    },
    [activeUid, authMode, firebaseUser, showToast, userRole]
  );

  const cancelOrder = useCallback(
    async (payload: { orderId: string; reason: string; location?: string }) => {
      const cleanId = payload.orderId.trim().toUpperCase();
      const cleanReason = payload.reason.trim() || 'Cancelled upon request';
      const defaultLocation =
        userRole === 'customer'
          ? 'Customer Portal'
          : userRole === 'staff'
            ? 'Fulfillment Center'
            : 'Admin Operations Center';
      const cleanLocation = payload.location?.trim() || defaultLocation;

      if (authMode === 'live' && firebaseUser) {
        const result = await cancelLiveOrder({
          orderId: cleanId,
          reason: cleanReason,
          location: cleanLocation,
          updatedByUid: firebaseUser.uid,
          updatedByRole: userRole,
        });
        showToast(
          result.refunded
            ? `Order ${cleanId} cancelled and marked as Refunded.`
            : `Order ${cleanId} has been cancelled.`,
          'success'
        );
        return;
      }

      // Demo Sandbox Cancellation
      const targetOrder = demoOrders.find((o) => o.orderId === cleanId);
      if (!targetOrder) {
        throw new Error(`Order ${cleanId} not found.`);
      }
      if (targetOrder.status === 'Cancelled') {
        throw new Error(`Order ${cleanId} is already cancelled.`);
      }
      if (targetOrder.status === 'Delivered') {
        throw new Error('Delivered orders cannot be cancelled.');
      }
      if (
        userRole === 'customer' &&
        targetOrder.status !== 'Order Placed' &&
        targetOrder.status !== 'Order Confirmed'
      ) {
        throw new Error(
          `Order ${cleanId} is already "${targetOrder.status}" and can no longer be self-cancelled.`
        );
      }
      if (
        userRole === 'staff' &&
        targetOrder.status !== 'Order Placed' &&
        targetOrder.status !== 'Order Confirmed' &&
        targetOrder.status !== 'Packed'
      ) {
        throw new Error(
          `Fulfillment staff cannot cancel orders once they reach "${targetOrder.status}".`
        );
      }

      const nowIso = new Date().toISOString();
      const refunded = targetOrder.paymentStatus === 'Paid';
      const nextPaymentStatus = refunded ? 'Refunded' : targetOrder.paymentStatus;
      const roleLabel =
        userRole === 'customer'
          ? 'customer'
          : userRole === 'staff'
            ? 'fulfillment staff'
            : 'administrator';

      // Restore stock in demo catalog
      if (targetOrder.items && targetOrder.items.length > 0) {
        setDemoProducts((prev) =>
          prev.map((p) => {
            const matchedItem = targetOrder.items?.find((i) => i.productId === p.productId);
            return matchedItem
              ? { ...p, stock: p.stock + matchedItem.quantity, updatedAt: nowIso }
              : p;
          })
        );
      }

      setDemoOrders((prev) =>
        prev.map((o) =>
          o.orderId === cleanId
            ? {
                ...o,
                status: 'Cancelled',
                paymentStatus: nextPaymentStatus,
                expectedDelivery: 'Cancelled',
                cancellationReason: cleanReason,
                updatedAt: nowIso,
              }
            : o
        )
      );

      setDemoPayments((prev) =>
        prev.map((p) =>
          p.orderId === cleanId && p.status === 'Paid' ? { ...p, status: 'Refunded' } : p
        )
      );

      setDemoTrackingMap((prev) => {
        const existing = prev[cleanId];
        if (!existing) return prev;
        return {
          ...prev,
          [cleanId]: {
            ...existing,
            currentStatus: 'Cancelled',
            paymentStatus: nextPaymentStatus,
            expectedDelivery: 'Cancelled',
            cancellationReason: cleanReason,
            updatedAt: nowIso,
            history: [
              ...existing.history,
              {
                trackingId: `trk-${Date.now()}`,
                orderId: cleanId,
                status: 'Cancelled',
                location: cleanLocation,
                description: `Order cancelled by ${roleLabel}. Reason: ${cleanReason}.${
                  refunded ? ' Prepaid amount marked as Refunded.' : ''
                }`,
                updatedByUid: activeUid,
                updatedByRole: userRole,
                timestamp: nowIso,
              },
            ],
          },
        };
      });

      showToast(
        refunded
          ? `Order ${cleanId} cancelled and marked as Refunded.`
          : `Order ${cleanId} has been cancelled.`,
        'success'
      );
    },
    [activeUid, authMode, demoOrders, firebaseUser, showToast, userRole]
  );

  const updateProfile = useCallback(
    async (updates: {
      name: string;
      phone: string;
      defaultAddress: string;
      cityRegion: string;
    }) => {
      if (authMode === 'live' && firebaseUser) {
        await updateCustomerProfileLive(firebaseUser.uid, updates);
        setCustomerProfile((prev) =>
          prev ? { ...prev, ...updates, updatedAt: new Date().toISOString() } : prev
        );
        showToast('Profile settings saved', 'success');
        return;
      }

      setDemoCustomers((prev) =>
        prev.map((c, idx) => (idx === 0 ? { ...c, ...updates } : c))
      );
      setCustomerProfile((prev) => (prev ? { ...prev, ...updates } : prev));
      showToast('Demo profile updated', 'success');
    },
    [authMode, firebaseUser, showToast]
  );

  const updateProductStock = useCallback(
    async (productId: string, newStock: number) => {
      const safeStock = Math.max(0, Math.floor(newStock));
      if (authMode === 'live' && firebaseUser) {
        await updateLiveProductStock(productId, safeStock);
        showToast('Inventory stock updated', 'success');
        return;
      }
      setDemoProducts((prev) =>
        prev.map((p) => (p.productId === productId ? { ...p, stock: safeStock } : p))
      );
      showToast('Inventory stock updated', 'success');
    },
    [authMode, firebaseUser, showToast]
  );

  const saveProduct = useCallback(
    async (product: Omit<Product, 'createdAt' | 'updatedAt'>, isNew: boolean) => {
      if (authMode === 'live' && firebaseUser) {
        await upsertLiveProduct(product, isNew);
        showToast(isNew ? 'Product created' : 'Product updated', 'success');
        return;
      }
      const nowIso = new Date().toISOString();
      if (isNew) {
        setDemoProducts((prev) => [{ ...product, createdAt: nowIso, updatedAt: nowIso }, ...prev]);
      } else {
        setDemoProducts((prev) =>
          prev.map((p) =>
            p.productId === product.productId ? { ...p, ...product, updatedAt: nowIso } : p
          )
        );
      }
      showToast(isNew ? 'Product created' : 'Product updated', 'success');
    },
    [authMode, firebaseUser, showToast]
  );

  const saveStaff = useCallback(
    async (staff: Omit<StaffMember, 'createdAt'>) => {
      if (authMode === 'live' && firebaseUser) {
        await upsertStaffLive(staff);
        const list = await fetchAllStaffLive();
        setLiveStaff(list);
        showToast('Staff member saved', 'success');
        return;
      }
      setDemoStaff((prev) => {
        const exists = prev.some((s) => s.uid === staff.uid);
        if (exists) {
          return prev.map((s) => (s.uid === staff.uid ? { ...s, ...staff } : s));
        }
        return [{ ...staff, createdAt: new Date().toISOString() }, ...prev];
      });
      showToast('Staff member saved', 'success');
    },
    [authMode, firebaseUser, showToast]
  );

  const saveAgent = useCallback(
    async (agent: Omit<DeliveryAgent, 'createdAt'>) => {
      if (authMode === 'live' && firebaseUser) {
        await upsertAgentLive(agent);
        const list = await fetchAllAgentsLive();
        setLiveAgents(list);
        showToast('Delivery agent saved', 'success');
        return;
      }
      setDemoAgents((prev) => {
        const exists = prev.some((a) => a.uid === agent.uid);
        if (exists) {
          return prev.map((a) => (a.uid === agent.uid ? { ...a, ...agent } : a));
        }
        return [{ ...agent, createdAt: new Date().toISOString() }, ...prev];
      });
      showToast('Delivery agent saved', 'success');
    },
    [authMode, firebaseUser, showToast]
  );

  const seedCatalogToFirestore = useCallback(async () => {
    if (authMode !== 'live' || userRole !== 'admin') return;
    await seedLiveProducts();
    showToast('Starter catalog seeded to Cloud Firestore!', 'success');
  }, [authMode, showToast, userRole]);

  const loadOrderItems = useCallback(
    async (orderId: string) => {
      if (authMode !== 'live') return;
      const items = await fetchOrderItemsLive(orderId);
      setLiveOrders((prev) =>
        prev.map((o) => (o.orderId === orderId ? { ...o, items } : o))
      );
    },
    [authMode]
  );

  return (
    <CotsContext.Provider
      value={{
        view,
        setView,
        navigateToTrack,
        activeTrackingId,
        setActiveTrackingId,
        authReady,
        authMode,
        firebaseUser,
        userRole,
        activeUserName,
        activeUserEmail,
        activeUid,
        customerProfile,
        authModalOpen,
        setAuthModalOpen,
        signInWithGoogle,
        enterDemoMode,
        logout,
        products,
        orders,
        customers,
        staffList,
        deliveryAgents,
        payments,
        dataLoading,
        cart,
        cartOpen,
        setCartOpen,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearCart,
        toasts,
        showToast,
        dismissToast,
        trackOrder,
        placeOrder,
        updateOrderStatus,
        cancelOrder,
        updateProfile,
        updateProductStock,
        saveProduct,
        saveStaff,
        saveAgent,
        seedCatalogToFirestore,
        loadOrderItems,
      }}
    >
      {children}
    </CotsContext.Provider>
  );
};

export function useCots() {
  const ctx = useContext(CotsContext);
  if (!ctx) throw new Error('useCots must be used within CotsProvider');
  return ctx;
}
