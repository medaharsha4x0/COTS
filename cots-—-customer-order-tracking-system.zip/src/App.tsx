/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { CotsProvider, useCots } from './context/CotsContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { OrderTrackingView } from './components/OrderTrackingView';
import { ProductsPage } from './components/ProductsPage';
import { CustomerDashboard } from './components/dashboards/CustomerDashboard';
import { StaffDashboard } from './components/dashboards/StaffDashboard';
import { DeliveryAgentDashboard } from './components/dashboards/DeliveryAgentDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { AuthModal } from './components/ui/AuthModal';
import { CartDrawer } from './components/ui/CartDrawer';
import { ToastContainer } from './components/ui/ToastContainer';

const CotsRouter: React.FC = () => {
  const { view } = useCots();

  const isDashboardView =
    view === 'customer-dashboard' ||
    view === 'staff-dashboard' ||
    view === 'agent-dashboard' ||
    view === 'admin-dashboard';

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A]">
      {!isDashboardView && <Navbar />}

      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        >
          {view === 'landing' && <LandingPage />}
          {view === 'track' && <OrderTrackingView />}
          {view === 'products' && <ProductsPage />}
          {view === 'about' && <LandingPage />}
          {view === 'customer-dashboard' && <CustomerDashboard />}
          {view === 'staff-dashboard' && <StaffDashboard />}
          {view === 'agent-dashboard' && <DeliveryAgentDashboard />}
          {view === 'admin-dashboard' && <AdminDashboard />}
        </motion.div>
      </AnimatePresence>

      <AuthModal />
      <CartDrawer />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <CotsProvider>
        <CotsRouter />
      </CotsProvider>
    </ErrorBoundary>
  );
}
