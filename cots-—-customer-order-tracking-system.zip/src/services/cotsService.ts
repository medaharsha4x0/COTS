import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { DEMO_PRODUCTS } from '../data/demoData';
import {
  ADMIN_BOOTSTRAP_EMAIL,
  db,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  CartItem,
  CustomerProfile,
  DeliveryAgent,
  Order,
  OrderItem,
  OrderStatus,
  OrderTrackingRecord,
  PaymentMethod,
  PaymentRecord,
  PaymentStatus,
  Product,
  ShipmentTrackingEntry,
  StaffMember,
  UserRole,
  VALIDATION_LIMITS,
} from '../types/cots';

export function formatTimestamp(value: unknown): string {
  if (!value) return new Date().toISOString();
  if (typeof value === 'string') return value;
  if (value instanceof Timestamp) return value.toDate().toISOString();
  if (typeof value === 'object' && value !== null && 'toDate' in value) {
    return (value as { toDate: () => Date }).toDate().toISOString();
  }
  return new Date().toISOString();
}

export function generateUniqueOrderId(): string {
  const num = Math.floor(100000 + Math.random() * 900000);
  return `COTS-2026-${num}`;
}

export function sanitizeText(input: string, maxLen: number): string {
  return input.trim().slice(0, maxLen);
}

export function isValidFirestoreId(id: string): boolean {
  return (
    id.length >= 1 &&
    id.length <= VALIDATION_LIMITS.idMax &&
    VALIDATION_LIMITS.idPattern.test(id)
  );
}

export async function resolveUserRole(user: User): Promise<UserRole> {
  if (
    user.email?.toLowerCase() === ADMIN_BOOTSTRAP_EMAIL.toLowerCase() &&
    user.emailVerified
  ) {
    return 'admin';
  }
  try {
    const adminSnap = await getDoc(doc(db, 'admins', user.uid));
    if (adminSnap.exists()) return 'admin';
  } catch {
    // Non-admin read is restricted; ignore if not admin
  }
  try {
    const staffSnap = await getDoc(doc(db, 'staff', user.uid));
    if (staffSnap.exists() && staffSnap.data().isActive !== false) return 'staff';
  } catch {
    // Ignore if not staff
  }
  try {
    const agentSnap = await getDoc(doc(db, 'delivery_agents', user.uid));
    if (agentSnap.exists() && agentSnap.data().isActive !== false)
      return 'delivery_agent';
  } catch {
    // Ignore if not delivery agent
  }
  return 'customer';
}

export async function syncCustomerProfile(user: User): Promise<CustomerProfile> {
  const ref = doc(db, 'customers', user.uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data();
      return {
        uid: data.uid,
        name: data.name,
        email: data.email,
        phone: data.phone || '',
        defaultAddress: data.defaultAddress || '',
        cityRegion: data.cityRegion || '',
        totalOrders: data.totalOrders || 0,
        createdAt: formatTimestamp(data.createdAt),
        updatedAt: formatTimestamp(data.updatedAt),
      };
    }

    const newProfile = {
      uid: user.uid,
      name: sanitizeText(user.displayName || 'COTS Customer', VALIDATION_LIMITS.nameMax),
      email: sanitizeText(user.email || 'customer@cots.app', VALIDATION_LIMITS.emailMax),
      phone: '',
      defaultAddress: '',
      cityRegion: '',
      totalOrders: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(ref, newProfile);
    const nowIso = new Date().toISOString();
    return {
      ...newProfile,
      createdAt: nowIso,
      updatedAt: nowIso,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `customers/${user.uid}`);
  }
}

export async function updateCustomerProfileLive(
  uid: string,
  updates: {
    name: string;
    phone: string;
    defaultAddress: string;
    cityRegion: string;
  }
): Promise<void> {
  const path = `customers/${uid}`;
  try {
    await updateDoc(doc(db, 'customers', uid), {
      name: sanitizeText(updates.name, VALIDATION_LIMITS.nameMax),
      phone: sanitizeText(updates.phone, VALIDATION_LIMITS.phoneMax),
      defaultAddress: sanitizeText(updates.defaultAddress, VALIDATION_LIMITS.addressMax),
      cityRegion: sanitizeText(updates.cityRegion, VALIDATION_LIMITS.cityMax),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchProductsLive(includeInactive = false): Promise<Product[]> {
  const path = 'products';
  try {
    const colRef = collection(db, path);
    const q = includeInactive
      ? colRef
      : query(colRef, where('isActive', '==', true));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        productId: data.productId,
        sku: data.sku,
        name: data.name,
        category: data.category,
        description: data.description || '',
        price: Number(data.price),
        stock: Number(data.stock),
        imageUrl: data.imageUrl,
        isActive: Boolean(data.isActive),
        createdAt: formatTimestamp(data.createdAt),
        updatedAt: formatTimestamp(data.updatedAt),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function seedLiveProducts(): Promise<void> {
  const path = 'products';
  try {
    const batch = writeBatch(db);
    for (const p of DEMO_PRODUCTS) {
      const ref = doc(db, path, p.productId);
      batch.set(ref, {
        productId: p.productId,
        sku: p.sku,
        name: p.name,
        category: p.category,
        description: p.description || '',
        price: p.price,
        stock: p.stock,
        imageUrl: p.imageUrl,
        isActive: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function upsertLiveProduct(
  product: Omit<Product, 'createdAt' | 'updatedAt'>,
  isNew: boolean
): Promise<void> {
  const path = `products/${product.productId}`;
  try {
    if (isNew) {
      await setDoc(doc(db, 'products', product.productId), {
        ...product,
        name: sanitizeText(product.name, 140),
        sku: sanitizeText(product.sku, 40),
        category: sanitizeText(product.category, 60),
        description: sanitizeText(product.description || '', 600),
        stock: Math.max(0, Math.floor(product.stock)),
        price: Math.max(0.01, Number(product.price)),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(doc(db, 'products', product.productId), {
        name: sanitizeText(product.name, 140),
        sku: sanitizeText(product.sku, 40),
        category: sanitizeText(product.category, 60),
        description: sanitizeText(product.description || '', 600),
        stock: Math.max(0, Math.floor(product.stock)),
        price: Math.max(0.01, Number(product.price)),
        imageUrl: sanitizeText(product.imageUrl, 500),
        isActive: product.isActive,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateLiveProductStock(
  productId: string,
  newStock: number
): Promise<void> {
  const path = `products/${productId}`;
  try {
    await updateDoc(doc(db, 'products', productId), {
      stock: Math.max(0, Math.floor(newStock)),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchOrderTrackingLive(
  orderId: string,
  hasFullAccess: boolean
): Promise<OrderTrackingRecord | null> {
  const cleanId = orderId.trim();
  if (!isValidFirestoreId(cleanId)) return null;

  const trackPath = `order_tracking/${cleanId}`;
  try {
    const trackSnap = await getDoc(doc(db, 'order_tracking', cleanId));
    if (!trackSnap.exists()) return null;

    const t = trackSnap.data();
    const historyQuery = query(
      collection(db, 'order_tracking', cleanId, 'history'),
      where('orderId', '==', cleanId)
    );
    const historySnap = await getDocs(historyQuery);
    const history: ShipmentTrackingEntry[] = historySnap.docs
      .map((d) => {
        const h = d.data();
        return {
          trackingId: h.trackingId,
          orderId: h.orderId,
          status: h.status as OrderStatus,
          location: h.location,
          description: h.description,
          updatedByUid: h.updatedByUid,
          updatedByRole: h.updatedByRole as UserRole,
          timestamp: formatTimestamp(h.timestamp),
        };
      })
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    let deliveryAddress: string | undefined;
    let customerName: string | undefined;
    let items: OrderItem[] | undefined;

    if (hasFullAccess) {
      try {
        const orderSnap = await getDoc(doc(db, 'orders', cleanId));
        if (orderSnap.exists()) {
          const o = orderSnap.data();
          deliveryAddress = o.deliveryAddress;
          customerName = o.customerName;
        }
        const itemsSnap = await getDocs(
          query(collection(db, 'orders', cleanId, 'items'), where('orderId', '==', cleanId))
        );
        items = itemsSnap.docs.map((d) => d.data() as OrderItem);
      } catch {
        // Viewer does not own this order; keep PII hidden
      }
    }

    return {
      orderId: t.orderId,
      customerUid: t.customerUid,
      currentStatus: t.currentStatus as OrderStatus,
      paymentStatus: t.paymentStatus as PaymentStatus,
      cityRegion: t.cityRegion,
      expectedDelivery: t.expectedDelivery,
      totalAmount: Number(t.totalAmount),
      itemSummary: t.itemSummary,
      itemCount: Number(t.itemCount),
      cancellationReason: t.cancellationReason || undefined,
      isDemo: Boolean(t.isDemo),
      createdAt: formatTimestamp(t.createdAt),
      updatedAt: formatTimestamp(t.updatedAt),
      deliveryAddress,
      customerName,
      items,
      history,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, trackPath);
  }
}

export async function placeLiveOrder(params: {
  user: User;
  customerProfile: CustomerProfile | null;
  cart: CartItem[];
  customerName: string;
  phone: string;
  deliveryAddress: string;
  cityRegion: string;
  paymentMethod: PaymentMethod;
}): Promise<string> {
  const { user, customerProfile, cart, customerName, phone, deliveryAddress, cityRegion, paymentMethod } = params;
  const orderId = generateUniqueOrderId();
  const paymentId = `pay-${Date.now()}`;
  const trackingId = `trk-${Date.now()}-1`;

  const totalAmount = cart.reduce((sum, c) => sum + c.product.price * c.quantity, 0);
  const itemCount = cart.reduce((sum, c) => sum + c.quantity, 0);
  const itemSummary = sanitizeText(
    cart.map((c) => (c.quantity > 1 ? `${c.product.name} (x${c.quantity})` : c.product.name)).join(', '),
    300
  );
  const expectedDate = new Date(Date.now() + 4 * 86400000).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  const paymentStatus: PaymentStatus = paymentMethod === 'Cash on Delivery' ? 'Pending' : 'Paid';

  try {
    // Verify current stock before batch write
    const freshStocks: Record<string, number> = {};
    for (const item of cart) {
      const pSnap = await getDoc(doc(db, 'products', item.product.productId));
      if (!pSnap.exists()) {
        throw new Error(`Product "${item.product.name}" is no longer available.`);
      }
      const stock = Number(pSnap.data().stock);
      if (stock < item.quantity) {
        throw new Error(`Insufficient stock for "${item.product.name}" (${stock} left).`);
      }
      freshStocks[item.product.productId] = stock;
    }

    const batch = writeBatch(db);

    batch.set(doc(db, 'orders', orderId), {
      orderId,
      customerUid: user.uid,
      customerName: sanitizeText(customerName, VALIDATION_LIMITS.nameMax),
      customerEmail: sanitizeText(user.email || 'customer@cots.app', VALIDATION_LIMITS.emailMax),
      phone: sanitizeText(phone, VALIDATION_LIMITS.phoneMax),
      deliveryAddress: sanitizeText(deliveryAddress, VALIDATION_LIMITS.addressMax),
      cityRegion: sanitizeText(cityRegion, VALIDATION_LIMITS.cityMax),
      status: 'Order Placed',
      paymentStatus,
      totalAmount: Number(totalAmount.toFixed(2)),
      itemCount,
      expectedDelivery: expectedDate,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    cart.forEach((c, idx) => {
      const orderItemId = `item-${Date.now()}-${idx + 1}`;
      batch.set(doc(db, 'orders', orderId, 'items', orderItemId), {
        orderItemId,
        orderId,
        customerUid: user.uid,
        productId: c.product.productId,
        productName: sanitizeText(c.product.name, 140),
        productImage: sanitizeText(c.product.imageUrl, 500),
        quantity: c.quantity,
        unitPrice: c.product.price,
        subtotal: Number((c.product.price * c.quantity).toFixed(2)),
      });

      batch.update(doc(db, 'products', c.product.productId), {
        stock: freshStocks[c.product.productId] - c.quantity,
        updatedAt: serverTimestamp(),
      });
    });

    batch.set(doc(db, 'order_tracking', orderId), {
      orderId,
      customerUid: user.uid,
      currentStatus: 'Order Placed',
      paymentStatus,
      cityRegion: sanitizeText(cityRegion, VALIDATION_LIMITS.cityMax),
      expectedDelivery: expectedDate,
      totalAmount: Number(totalAmount.toFixed(2)),
      itemSummary,
      itemCount,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'order_tracking', orderId, 'history', trackingId), {
      trackingId,
      orderId,
      status: 'Order Placed',
      location: 'Online Checkout · COTS Storefront',
      description: `Order placed by customer. Payment method: ${paymentMethod} (${paymentStatus}).`,
      updatedByUid: user.uid,
      updatedByRole: 'customer',
      timestamp: serverTimestamp(),
    });

    batch.set(doc(db, 'payments', paymentId), {
      paymentId,
      orderId,
      customerUid: user.uid,
      amount: Number(totalAmount.toFixed(2)),
      method: paymentMethod,
      status: paymentStatus,
      transactionRef: `TXN-${Date.now().toString().slice(-6)}`,
      createdAt: serverTimestamp(),
    });

    if (customerProfile) {
      batch.update(doc(db, 'customers', user.uid), {
        totalOrders: (customerProfile.totalOrders || 0) + 1,
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
    return orderId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `orders/${orderId}`);
  }
}

export async function updateLiveOrderStatus(params: {
  orderId: string;
  newStatus: OrderStatus;
  location: string;
  description: string;
  updatedByUid: string;
  updatedByRole: UserRole;
  assignedAgentUid?: string;
  assignedAgentName?: string;
}): Promise<void> {
  const {
    orderId,
    newStatus,
    location,
    description,
    updatedByUid,
    updatedByRole,
    assignedAgentUid,
    assignedAgentName,
  } = params;
  const trackingId = `trk-${Date.now()}`;
  const path = `orders/${orderId}`;

  try {
    const batch = writeBatch(db);
    const orderUpdate: Record<string, unknown> = {
      status: newStatus,
      updatedAt: serverTimestamp(),
    };
    if (assignedAgentUid !== undefined && assignedAgentName !== undefined) {
      orderUpdate.assignedAgentUid = sanitizeText(assignedAgentUid, 128);
      orderUpdate.assignedAgentName = sanitizeText(assignedAgentName, 120);
    }

    batch.update(doc(db, 'orders', orderId), orderUpdate);
    batch.update(doc(db, 'order_tracking', orderId), {
      currentStatus: newStatus,
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'order_tracking', orderId, 'history', trackingId), {
      trackingId,
      orderId,
      status: newStatus,
      location: sanitizeText(location, 160),
      description: sanitizeText(description, 320),
      updatedByUid,
      updatedByRole,
      timestamp: serverTimestamp(),
    });

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function cancelLiveOrder(params: {
  orderId: string;
  reason: string;
  location: string;
  updatedByUid: string;
  updatedByRole: UserRole;
}): Promise<{ refunded: boolean; totalAmount: number }> {
  const { orderId, reason, location, updatedByUid, updatedByRole } = params;
  const cleanOrderId = orderId.trim();
  const cleanReason = sanitizeText(reason || 'Cancelled upon request', VALIDATION_LIMITS.cancellationReasonMax);
  const path = `orders/${cleanOrderId}`;

  try {
    const orderRef = doc(db, 'orders', cleanOrderId);
    const orderSnap = await getDoc(orderRef);
    if (!orderSnap.exists()) {
      throw new Error(`Order ${cleanOrderId} could not be found.`);
    }

    const orderData = orderSnap.data();
    const currentStatus = orderData.status as OrderStatus;
    const currentPaymentStatus = orderData.paymentStatus as PaymentStatus;
    const customerUid = orderData.customerUid as string;
    const totalAmount = Number(orderData.totalAmount || 0);

    if (currentStatus === 'Cancelled') {
      throw new Error(`Order ${cleanOrderId} has already been cancelled.`);
    }
    if (currentStatus === 'Delivered') {
      throw new Error('Delivered orders cannot be cancelled.');
    }
    if (
      updatedByRole === 'customer' &&
      currentStatus !== 'Order Placed' &&
      currentStatus !== 'Order Confirmed'
    ) {
      throw new Error(
        `Order ${cleanOrderId} is already "${currentStatus}" and can no longer be self-cancelled.`
      );
    }
    if (
      updatedByRole === 'staff' &&
      currentStatus !== 'Order Placed' &&
      currentStatus !== 'Order Confirmed' &&
      currentStatus !== 'Packed'
    ) {
      throw new Error(
        `Fulfillment staff cannot cancel orders once they reach "${currentStatus}".`
      );
    }

    const refunded = currentPaymentStatus === 'Paid';
    const nextPaymentStatus: PaymentStatus = refunded ? 'Refunded' : currentPaymentStatus;
    const trackingId = `trk-${Date.now()}`;

    const batch = writeBatch(db);

    batch.update(orderRef, {
      status: 'Cancelled',
      paymentStatus: nextPaymentStatus,
      expectedDelivery: 'Cancelled',
      cancellationReason: cleanReason,
      updatedAt: serverTimestamp(),
    });

    batch.update(doc(db, 'order_tracking', cleanOrderId), {
      currentStatus: 'Cancelled',
      paymentStatus: nextPaymentStatus,
      expectedDelivery: 'Cancelled',
      cancellationReason: cleanReason,
      updatedAt: serverTimestamp(),
    });

    const roleLabel =
      updatedByRole === 'customer'
        ? 'customer'
        : updatedByRole === 'staff'
          ? 'fulfillment staff'
          : 'administrator';
    const refundNote = refunded
      ? ' Prepaid payment marked as Refunded.'
      : '';
    const description = sanitizeText(
      `Order cancelled by ${roleLabel}. Reason: ${cleanReason}.${refundNote}`,
      VALIDATION_LIMITS.descMax
    );

    batch.set(doc(db, 'order_tracking', cleanOrderId, 'history', trackingId), {
      trackingId,
      orderId: cleanOrderId,
      status: 'Cancelled',
      location: sanitizeText(location || 'Customer Portal', 160),
      description,
      updatedByUid,
      updatedByRole,
      timestamp: serverTimestamp(),
    });

    // Update payment record to Refunded when viewer has permission (customer owner or admin)
    if (refunded && (updatedByRole === 'customer' || updatedByRole === 'admin')) {
      const paymentSnap = await getDocs(
        query(
          collection(db, 'payments'),
          where('orderId', '==', cleanOrderId),
          where('customerUid', '==', customerUid)
        )
      );
      paymentSnap.docs.forEach((pDoc) => {
        if (pDoc.data().status === 'Paid') {
          batch.update(pDoc.ref, { status: 'Refunded' });
        }
      });
    }

    // Restore product stock atomically when staff or admin cancels
    if (updatedByRole === 'staff' || updatedByRole === 'admin') {
      const itemsSnap = await getDocs(
        query(collection(db, 'orders', cleanOrderId, 'items'), where('orderId', '==', cleanOrderId))
      );
      for (const itemDoc of itemsSnap.docs) {
        const item = itemDoc.data();
        if (item.productId && Number(item.quantity) > 0) {
          const pRef = doc(db, 'products', item.productId);
          const pSnap = await getDoc(pRef);
          if (pSnap.exists()) {
            const currentStock = Number(pSnap.data().stock || 0);
            batch.update(pRef, {
              stock: currentStock + Number(item.quantity),
              updatedAt: serverTimestamp(),
            });
          }
        }
      }
    }

    await batch.commit();
    return { refunded, totalAmount };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('cannot') ||
        error.message.includes('already') ||
        error.message.includes('could not be found'))
    ) {
      throw error;
    }
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchOrderItemsLive(orderId: string): Promise<OrderItem[]> {
  const path = `orders/${orderId}/items`;
  try {
    const snap = await getDocs(
      query(collection(db, 'orders', orderId, 'items'), where('orderId', '==', orderId))
    );
    return snap.docs.map((d) => d.data() as OrderItem);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function fetchAllStaffLive(): Promise<StaffMember[]> {
  try {
    const snap = await getDocs(collection(db, 'staff'));
    return snap.docs.map((d) => {
      const s = d.data();
      return {
        uid: s.uid,
        name: s.name,
        email: s.email,
        department: s.department,
        shift: s.shift,
        isActive: Boolean(s.isActive),
        createdAt: formatTimestamp(s.createdAt),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'staff');
  }
}

export async function upsertStaffLive(staff: Omit<StaffMember, 'createdAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'staff', staff.uid), {
      uid: sanitizeText(staff.uid, 128),
      name: sanitizeText(staff.name, 120),
      email: sanitizeText(staff.email, 180),
      department: sanitizeText(staff.department, 80),
      shift: sanitizeText(staff.shift, 40),
      isActive: staff.isActive,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `staff/${staff.uid}`);
  }
}

export async function fetchAllAgentsLive(): Promise<DeliveryAgent[]> {
  try {
    const snap = await getDocs(collection(db, 'delivery_agents'));
    return snap.docs.map((d) => {
      const a = d.data();
      return {
        uid: a.uid,
        name: a.name,
        email: a.email,
        phone: a.phone || '',
        vehicleType: a.vehicleType,
        zone: a.zone,
        isActive: Boolean(a.isActive),
        createdAt: formatTimestamp(a.createdAt),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'delivery_agents');
  }
}

export async function upsertAgentLive(agent: Omit<DeliveryAgent, 'createdAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'delivery_agents', agent.uid), {
      uid: sanitizeText(agent.uid, 128),
      name: sanitizeText(agent.name, 120),
      email: sanitizeText(agent.email, 180),
      phone: sanitizeText(agent.phone || '', 32),
      vehicleType: sanitizeText(agent.vehicleType, 60),
      zone: sanitizeText(agent.zone, 80),
      isActive: agent.isActive,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `delivery_agents/${agent.uid}`);
  }
}

export async function fetchAllCustomersLive(): Promise<CustomerProfile[]> {
  try {
    const snap = await getDocs(collection(db, 'customers'));
    return snap.docs.map((d) => {
      const c = d.data();
      return {
        uid: c.uid,
        name: c.name,
        email: c.email,
        phone: c.phone || '',
        defaultAddress: c.defaultAddress || '',
        cityRegion: c.cityRegion || '',
        totalOrders: Number(c.totalOrders || 0),
        createdAt: formatTimestamp(c.createdAt),
        updatedAt: formatTimestamp(c.updatedAt),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'customers');
  }
}

export async function fetchAllPaymentsLive(): Promise<PaymentRecord[]> {
  try {
    const snap = await getDocs(collection(db, 'payments'));
    return snap.docs.map((d) => {
      const p = d.data();
      return {
        paymentId: p.paymentId,
        orderId: p.orderId,
        customerUid: p.customerUid,
        amount: Number(p.amount),
        method: p.method as PaymentMethod,
        status: p.status as PaymentStatus,
        transactionRef: p.transactionRef,
        createdAt: formatTimestamp(p.createdAt),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'payments');
  }
}
