/**
 * COTS Firestore Security Rules Test Suite Specification
 * Verifies the "Dirty Dozen" adversarial payloads against the Eight Pillars.
 * Run against Firebase Emulator Suite when available.
 */

export interface DirtyDozenCase {
  id: number;
  name: string;
  collection: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  actor: 'anonymous' | 'customer' | 'staff' | 'delivery_agent' | 'unverified_admin';
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
  enforcedBy: string;
}

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Shadow Field Injection on Customer Create',
    collection: 'customers/cust_1',
    operation: 'create',
    actor: 'customer',
    payload: { uid: 'cust_1', name: 'Mallory', email: 'm@example.com', totalOrders: 0, isAdmin: true },
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'isValidCustomer() keys().hasOnly(...)',
  },
  {
    id: 2,
    name: 'Identity Spoofing on Order Create',
    collection: 'orders/COTS-9999',
    operation: 'create',
    actor: 'customer',
    payload: { orderId: 'COTS-9999', customerUid: 'victim_uid', status: 'Order Placed' },
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'isValidOrderCreate() customerUid == request.auth.uid',
  },
  {
    id: 3,
    name: 'State Shortcutting on Order Create',
    collection: 'orders/COTS-9998',
    operation: 'create',
    actor: 'customer',
    payload: { orderId: 'COTS-9998', customerUid: 'cust_1', status: 'Delivered' },
    expected: 'PERMISSION_DENIED',
    enforcedBy: "isValidOrderCreate() status == 'Order Placed'",
  },
  {
    id: 4,
    name: 'Self-Assigned Staff Privilege Escalation',
    collection: 'staff/cust_1',
    operation: 'create',
    actor: 'customer',
    payload: { uid: 'cust_1', name: 'Mallory', email: 'm@example.com', isActive: true },
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'allow write: if isAdmin()',
  },
  {
    id: 5,
    name: 'Customer Product Stock Inflation',
    collection: 'products/prod_1',
    operation: 'update',
    actor: 'customer',
    payload: { stock: 99999 },
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'incoming().stock < existing().stock && incoming().stock >= 0',
  },
  {
    id: 6,
    name: 'Staff Price Tampering',
    collection: 'products/prod_1',
    operation: 'update',
    actor: 'staff',
    payload: { price: 0.01 },
    expected: 'PERMISSION_DENIED',
    enforcedBy: "affectedKeys().hasOnly(['stock', 'updatedAt'])",
  },
  {
    id: 7,
    name: 'Blanket Customer Directory Scraping',
    collection: 'customers',
    operation: 'list',
    actor: 'customer',
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'allow list: if isAdmin()',
  },
  {
    id: 8,
    name: 'Cross-Customer Order Enumeration',
    collection: 'orders',
    operation: 'list',
    actor: 'customer',
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'resource.data.customerUid == request.auth.uid',
  },
  {
    id: 9,
    name: 'Public Tracking Collection Scrape',
    collection: 'order_tracking',
    operation: 'list',
    actor: 'anonymous',
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'allow list: if isStaff() || isDeliveryAgent() || isAdmin()',
  },
  {
    id: 10,
    name: 'Terminal State Cancellation Bypass',
    collection: 'orders/COTS-1001',
    operation: 'update',
    actor: 'customer',
    payload: { status: 'Cancelled' },
    expected: 'PERMISSION_DENIED',
    enforcedBy: "existing().status in ['Order Placed', 'Order Confirmed']",
  },
  {
    id: 11,
    name: 'Resource Poisoning via Invalid Order ID',
    collection: 'orders/' + 'x'.repeat(200),
    operation: 'create',
    actor: 'customer',
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'isValidId(orderId) size <= 128',
  },
  {
    id: 12,
    name: 'Unverified Email Admin Spoof',
    collection: 'admins/spoof_uid',
    operation: 'create',
    actor: 'unverified_admin',
    expected: 'PERMISSION_DENIED',
    enforcedBy: 'request.auth.token.email_verified == true',
  },
];
