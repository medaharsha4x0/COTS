# COTS Security Specification (Phase 0)

## 1. Data Invariants
1. **Identity Integrity**: A customer profile, order, order item, or payment can only be created when `request.auth != null` and `request.auth.token.email_verified == true`, with `customerUid == request.auth.uid`.
2. **No Self-Assigned Roles**: Customers cannot create or modify documents in `/admins`, `/staff`, or `/delivery_agents`. Only verified admins (bootstrapped admin `harsha2926ace@gmail.com` or `/admins/{uid}`) may manage roles.
3. **PII Isolation**: Customer street addresses, emails, and phone numbers live strictly in `/customers/{customerId}` and `/orders/{orderId}`. Public tracking uses `/order_tracking/{orderId}` (exact `get` only, `list` blocked for non-staff) containing only city/region, status, and item summary.
4. **Order State Integrity & Terminal Locking**: Orders must start in status `"Order Placed"`. Staff can only advance to `"Order Confirmed"`, `"Packed"`, or `"Shipped"`. Delivery agents can only advance to `"Out for Delivery"`, `"Delivered"`, or `"Delivery Failed"`. Customers can only transition from `"Order Placed"` or `"Order Confirmed"` to `"Cancelled"`. Once `"Delivered"` or `"Cancelled"`, non-admin modifications are permanently locked.
5. **Atomic Inventory & Tracking Sync**: Creating an order atomically creates `/orders/{orderId}` and `/order_tracking/{orderId}` (enforced via `existsAfter`). Customer product stock updates may only decrement `stock` (`incoming.stock < existing.stock && incoming.stock >= 0`) and touch only `['stock', 'updatedAt']`.
6. **Temporal Integrity & Path Hardening**: All document IDs match `^[a-zA-Z0-9_\-]+$` (`<= 128` chars), every string has explicit `.size()` bounds, and all server timestamps validate `== request.time`.

## 2. The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Shadow Field Injection on Customer Create**: `{ uid, name, email, totalOrders: 0, isAdmin: true, createdAt: serverTimestamp, updatedAt: serverTimestamp }` -> Denied by `hasOnly(...)`.
2. **Identity Spoofing on Order Create**: Signed-in user `uidA` creates `/orders/ORD-1` with `customerUid: "uidB"` -> Denied by `data.customerUid == request.auth.uid`.
3. **State Shortcutting on Order Create**: Customer creates `/orders/ORD-2` directly with `status: "Delivered"` -> Denied by `data.status == 'Order Placed'`.
4. **Privilege Escalation on Staff Collection**: Customer writes `/staff/{uid}` to grant themselves staff rights -> Denied by `isAdmin()`.
5. **Stock Inflation Attack**: Customer updates `/products/PROD-1` setting `stock: 9999` -> Denied by `incoming().stock < existing().stock`.
6. **Price Tampering on Product Update**: Staff updates `/products/PROD-1` changing `price` when only Admin may alter pricing -> Denied by `affectedKeys().hasOnly(['stock', 'updatedAt'])`.
7. **PII Scraping via List on Customers**: Authenticated customer runs `list` on `/customers` -> Denied by `allow list: if isAdmin()`.
8. **PII Scraping via List on Orders**: Customer `uidA` runs `list` on `/orders` without `where('customerUid', '==', uidA)` -> Denied by `resource.data.customerUid == request.auth.uid`.
9. **Unauthorized Public List on Tracking**: Anonymous user runs `list` on `/order_tracking` -> Denied by `allow list: if isStaff() || isDeliveryAgent() || isAdmin()`.
10. **Terminal State Bypass**: Customer tries to cancel an order whose current status is `"Shipped"` or `"Delivered"` -> Denied by terminal lock & eligible status check.
11. **Resource Poisoning via Oversized ID**: Attempt to write `/orders/` with a 500-character document ID or invalid characters (`../admin`) -> Denied by `isValidId(orderId)`.
12. **Unverified Email Spoofing**: Token with `email: "harsha2926ace@gmail.com"` and `email_verified: false` attempts admin write -> Denied by `request.auth.token.email_verified == true`.
